<?php
require_once __DIR__ . '/../includes/includes.php';

/* ── Handle AJAX partial requests ── */
$partial = $_GET['partial'] ?? '';
if ($partial === 'processing') { render_processing($db); exit; }
if ($partial === 'dashboard')  { render_dashboard($db);  exit; }
if ($partial === 'nodes')      { render_nodes($db);      exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JtR Cluster — Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../estilo.css?v=<?= filemtime(__DIR__ . '/../estilo.css') ?>">
</head>
<body>

<div class="page-header">
    <div class="d-flex align-items-center gap-3">
        <img src="../images/jtr_cluster_logo.png" alt="JtR Cluster" class="page-logo">
        <h1 class="h3 mb-0">Admin</h1>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-sm btn-outline-secondary" onclick="location.reload()">⟳ Refresh</button>
        <a href="../" class="btn btn-sm btn-outline-primary">← Back</a>
    </div>
</div>

<!-- Tabs nav -->
<ul class="nav nav-tabs" id="adminTabs" role="tablist">
    <?php
    $tabs = [
        'dashboard'      => 'Dashboard',
        'nodes'          => 'Nodes',
        'processing'     => 'Processing',
        'hashes-cracked' => 'Hashes cracked',
        'files-cracked'  => 'Files cracked',
    ];
    $first = true;
    foreach ($tabs as $id => $label):
    ?>
    <li class="nav-item" role="presentation">
        <button class="nav-link <?= $first ? 'active' : '' ?>"
                id="tab-<?= $id ?>" data-bs-toggle="tab"
                data-bs-target="#<?= $id ?>" type="button" role="tab">
            <?= $label ?>
        </button>
    </li>
    <?php $first = false; endforeach; ?>
</ul>

<div class="tab-content" id="adminTabsContent">

<!-- ══════════════════════════════════════
     DASHBOARD
══════════════════════════════════════ -->
<div class="tab-pane fade show active" id="dashboard" role="tabpanel">
    <div class="d-flex align-items-center gap-2 mb-3">
        <span class="spinner-border spinner-border-sm text-primary" role="status" aria-hidden="true"></span>
        <small class="text-muted">Auto-refreshing every 5 seconds</small>
    </div>
    <div id="dashboard-content">
        <?php render_dashboard($db); ?>
    </div>
</div>

<!-- ══════════════════════════════════════
     NODES
══════════════════════════════════════ -->
<div class="tab-pane fade" id="nodes" role="tabpanel">
    <div class="d-flex align-items-center gap-2 mb-3">
        <span class="spinner-border spinner-border-sm text-primary" role="status" aria-hidden="true"></span>
        <small class="text-muted">Auto-refreshing every 5 seconds</small>
    </div>
    <div id="nodes-content">
        <?php render_nodes($db); ?>
    </div>
</div>

<!-- ══════════════════════════════════════
     PROCESSING
══════════════════════════════════════ -->
<div class="tab-pane fade" id="processing" role="tabpanel">
    <div class="d-flex align-items-center gap-2 mb-3">
        <span class="spinner-border spinner-border-sm text-primary" role="status" aria-hidden="true"></span>
        <small class="text-muted">Auto-refreshing every 5 seconds</small>
    </div>
    <div id="processing-content">
        <?php render_processing($db); ?>
    </div>
</div>

<!-- ══════════════════════════════════════
     HASHES CRACKED
══════════════════════════════════════ -->
<div class="tab-pane fade" id="hashes-cracked" role="tabpanel">
    <?php render_hashes_cracked($db); ?>
</div>

<!-- ══════════════════════════════════════
     FILES CRACKED
══════════════════════════════════════ -->
<div class="tab-pane fade" id="files-cracked" role="tabpanel">
    <?php render_files_cracked($db); ?>
</div>

</div><!-- /tab-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Persist active tab across page loads
    const saved = localStorage.getItem('adminTab');
    if (saved) {
        const trigger = document.querySelector(`[data-bs-target='#${saved}']`);
        if (trigger) new bootstrap.Tab(trigger).show();
    }
    document.querySelectorAll('#adminTabs button[data-bs-toggle="tab"]').forEach(btn => {
        btn.addEventListener('shown.bs.tab', e => {
            const target = e.target.getAttribute('data-bs-target').replace('#', '');
            localStorage.setItem('adminTab', target);
        });
    });

    // Generic auto-refresh helper
    function makeAutoRefresh(partial, contentId) {
        let timer = null;
        function refresh() {
            fetch('index.php?partial=' + partial)
                .then(r => r.text())
                .then(html => {
                    const el = document.getElementById(contentId);
                    if (el) el.innerHTML = html;
                })
                .catch(() => {});
        }
        function start() { if (!timer) timer = setInterval(refresh, 5000); }
        function stop()  { clearInterval(timer); timer = null; }
        return { start, stop };
    }

    const tabs = {
        dashboard:  makeAutoRefresh('dashboard',  'dashboard-content'),
        nodes:      makeAutoRefresh('nodes',       'nodes-content'),
        processing: makeAutoRefresh('processing',  'processing-content'),
    };

    Object.entries(tabs).forEach(([id, ctrl]) => {
        const btn = document.querySelector(`[data-bs-target="#${id}"]`);
        if (!btn) return;
        btn.addEventListener('shown.bs.tab',  ctrl.start);
        btn.addEventListener('hidden.bs.tab', ctrl.stop);
    });

    // Start the currently active tab's auto-refresh
    const activeId = saved || 'dashboard';
    if (tabs[activeId]) tabs[activeId].start();
});
</script>
</body>
</html>
