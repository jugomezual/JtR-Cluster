<?php
require_once __DIR__ . '/../includes/includes.php';

/* ── Validate ID ─────────────────────────────────────────────────────────── */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    http_response_code(400);
    die('Invalid hash ID.');
}

/* ── Charset mappings ────────────────────────────────────────────────────── */
$CHARSET_NAMES = [
    0 => 'Digits only (0–9)',
    1 => 'Lowercase letters (a–z)',
    2 => 'Uppercase letters (A–Z)',
    3 => 'Letters & digits (A–Z, a–z, 0–9)',
    4 => 'All printable ASCII characters',
];
$CHARSET_SIZES = [0 => 10, 1 => 26, 2 => 26, 3 => 62, 4 => 95];

/* ── 1. Hash general info ────────────────────────────────────────────────── */
$stmt = $db->prepare("
    SELECT h.id, h.hash_type, h.hash_text, h.result, h.password_length,
           h.charset_id, h.created_at, h.completed_at AS end_at, h.comment
    FROM hashes h
    WHERE h.id = ?
      AND h.uploaded_file IS NULL
");
$stmt->bind_param('i', $id);
$stmt->execute();
$hash = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$hash) {
    http_response_code(404);
    die('Hash not found or not yet cracked.');
}

$charset_id   = (int)$hash['charset_id'];
$charset_name = $CHARSET_NAMES[$charset_id] ?? 'Unknown';
$charset_size = $CHARSET_SIZES[$charset_id] ?? 95;
$max_len      = (int)$hash['password_length'];

/* Compute total sample space: sum of charset_size^i for i = 1..max_len */
$sample_space = 0.0;
for ($i = 1; $i <= $max_len; $i++) {
    $sample_space += pow($charset_size, $i);
}

/* ── 2. Job distribution + total quantums ───────────────────────────────── */
$stmt = $db->prepare("
    SELECT
        COUNT(*)                                                     AS total_quantums,
        SUM(node_id IS NOT NULL AND status IN ('found','not_found')) AS done,
        SUM(node_id IS NULL     AND status = 'discarded')            AS discarded,
        SUM(status = 'pending')                                      AS pending,
        SUM(status = 'splited')                                      AS splited,
        SUM(status = 'joined')                                       AS joined
    FROM jobs WHERE hash_id = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$dist = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* ── 2b. Per-level breakdown ─────────────────────────────────────────────── */
$stmt = $db->prepare("
    SELECT
        level,
        COUNT(*)                                                         AS total,
        SUM(status = 'pending')                                          AS pending,
        SUM(status = 'processing')                                       AS processing,
        SUM(status IN ('found','not_found') AND node_id IS NOT NULL)    AS done,
        SUM(status = 'discarded')                                        AS discarded,
        SUM(status = 'splited')                                          AS splited,
        SUM(status = 'joined')                                           AS joined,
        AVG(CASE WHEN status IN ('found','not_found') AND node_id IS NOT NULL
                      AND assigned_at IS NOT NULL AND completed_at IS NOT NULL
                 THEN TIMESTAMPDIFF(SECOND, assigned_at, completed_at)
                 ELSE NULL END)                                          AS avg_secs
    FROM jobs
    WHERE hash_id = ?
    GROUP BY level
    ORDER BY level DESC
");
$stmt->bind_param('i', $id);
$stmt->execute();
$level_rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$total_quantums = max(1, (int)($dist['total_quantums'] ?? 1));

/* ── 2c. Combo-weighted coverage (for progress bar) ─────────────────────── */
$stmt = $db->prepare("
    SELECT
        SUM(CASE WHEN node_id IS NOT NULL AND status IN ('found','not_found')
                 THEN jobs_count * POW($charset_size, level) ELSE 0 END)  AS combos_done,
        SUM(CASE WHEN node_id IS NULL     AND status = 'discarded'
                 THEN jobs_count * POW($charset_size, level) ELSE 0 END)  AS combos_discarded,
        SUM(CASE WHEN status = 'pending'
                 THEN jobs_count * POW($charset_size, level) ELSE 0 END)  AS combos_pending,
        SUM(CASE WHEN status NOT IN ('splited','joined')
                 THEN jobs_count * POW($charset_size, level) ELSE 0 END)  AS combos_total
    FROM jobs WHERE hash_id = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$coverage = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* ── 3. CPU stats ────────────────────────────────────────────────────────── */
$stmt = $db->prepare("
    SELECT COUNT(*)                        AS jobs,
           COUNT(DISTINCT node_id, cpu_device_id) AS nodes,
           AVG(TIMESTAMPDIFF(SECOND, assigned_at, completed_at)) AS avg_secs,
           SUM(TIMESTAMPDIFF(SECOND, assigned_at, completed_at)) AS sum_secs,
           SUM(jobs_count * POW($charset_size, level))           AS total_combos
    FROM jobs
    WHERE hash_id = ?
      AND cpu_device_id IS NOT NULL
      AND node_id IS NOT NULL
      AND status IN ('found','not_found')
      AND assigned_at IS NOT NULL
      AND completed_at IS NOT NULL
");
$stmt->bind_param('i', $id);
$stmt->execute();
$cpu = $stmt->get_result()->fetch_assoc();
$stmt->close();

$cpu['sum_secs']     = (float)($cpu['sum_secs']     ?? 0);
$cpu['total_combos'] = (float)($cpu['total_combos'] ?? 0);
/* avg throughput (H/s) = actual combinations per level processed / total seconds */
$cpu['avg_throughput'] = ($cpu['sum_secs'] > 0 && $cpu['total_combos'] > 0)
    ? $cpu['total_combos'] / $cpu['sum_secs']
    : 0.0;

/* ── 4. GPU stats (only jobs at the GPU's own level) ─────────────────────── */
$stmt = $db->prepare("
    SELECT COUNT(*)                          AS jobs,
           COUNT(DISTINCT j.node_id, j.gpu_device_id) AS nodes,
           AVG(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at)) AS avg_secs,
           SUM(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at)) AS sum_secs,
           SUM(j.jobs_count * POW($charset_size, j.level))           AS total_combos
    FROM jobs j
    JOIN gpus g ON g.node_id = j.node_id AND g.device_id = j.gpu_device_id
    WHERE j.hash_id = ?
      AND j.gpu_device_id IS NOT NULL
      AND j.node_id IS NOT NULL
      AND j.status IN ('found','not_found')
      AND j.assigned_at IS NOT NULL
      AND j.completed_at IS NOT NULL
      AND j.level = g.level
");
$stmt->bind_param('i', $id);
$stmt->execute();
$gpu = $stmt->get_result()->fetch_assoc();
$stmt->close();

$gpu['sum_secs']     = (float)($gpu['sum_secs']     ?? 0);
$gpu['total_combos'] = (float)($gpu['total_combos'] ?? 0);
$gpu['avg_throughput'] = ($gpu['sum_secs'] > 0 && $gpu['total_combos'] > 0)
    ? $gpu['total_combos'] / $gpu['sum_secs']
    : 0.0;

/* ── 4b. Per-GPU breakdown ───────────────────────────────────────────────── */
$stmt = $db->prepare("
    SELECT n.ip,
           g.model,
           j.gpu_device_id                                                   AS device_id,
           COUNT(*)                                                           AS jobs,
           SUM(j.jobs_count)                                                 AS quanta,
           ROUND(SUM(j.jobs_count * POW($charset_size, j.level)) / 1e9, 3)  AS gcombos,
           SUM(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at))        AS sum_secs,
           ROUND(AVG(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at)))   AS avg_secs,
           ROUND(SUM(j.jobs_count * POW($charset_size, j.level))
                 / SUM(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at))
                 / 1e9, 3)                                                   AS ghs
    FROM jobs j
    JOIN gpus  g ON g.node_id = j.node_id AND g.device_id = j.gpu_device_id
    JOIN nodes n ON n.id = j.node_id
    WHERE j.hash_id = ?
      AND j.gpu_device_id IS NOT NULL
      AND j.node_id IS NOT NULL
      AND j.status IN ('found','not_found')
      AND j.assigned_at IS NOT NULL
      AND j.completed_at IS NOT NULL
      AND j.level = g.level
    GROUP BY j.node_id, j.gpu_device_id
    ORDER BY ghs DESC
");
$stmt->bind_param('i', $id);
$stmt->execute();
$gpu_breakdown = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

/* ── 4c. Per-node CPU breakdown ──────────────────────────────────────────────
 * Unlike the GPU breakdown (one row per physical device), CPU stats are
 * aggregated per node: all CPU cores of a node share the same throughput
 * profile for practical purposes, so one row = all CPU jobs processed by
 * that node's cores.
 */
$stmt = $db->prepare("
    SELECT n.ip,
           COUNT(DISTINCT j.cpu_device_id)                                   AS cpu_count,
           COUNT(*)                                                           AS jobs,
           SUM(j.jobs_count)                                                 AS quanta,
           ROUND(SUM(j.jobs_count * POW($charset_size, j.level)) / 1e9, 3)  AS gcombos,
           SUM(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at))        AS sum_secs,
           ROUND(AVG(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at)))   AS avg_secs,
           ROUND(SUM(j.jobs_count * POW($charset_size, j.level))
                 / SUM(TIMESTAMPDIFF(SECOND, j.assigned_at, j.completed_at))
                 / 1e9, 3)                                                   AS ghs
    FROM jobs j
    JOIN nodes n ON n.id = j.node_id
    WHERE j.hash_id = ?
      AND j.cpu_device_id IS NOT NULL
      AND j.node_id IS NOT NULL
      AND j.status IN ('found','not_found')
      AND j.assigned_at IS NOT NULL
      AND j.completed_at IS NOT NULL
    GROUP BY j.node_id
    ORDER BY ghs DESC
");
$stmt->bind_param('i', $id);
$stmt->execute();
$cpu_breakdown = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

/* ── 5. Timing ───────────────────────────────────────────────────────────── */
$total_node_secs = (int)($cpu['sum_secs'] + $gpu['sum_secs']);

/* Wall-clock time computed in PHP */
$wall_clock_secs = null;
if ($hash['created_at'] && $hash['end_at']) {
    $wall_clock_secs = (int)(strtotime($hash['end_at']) - strtotime($hash['created_at']));
    if ($wall_clock_secs < 0) $wall_clock_secs = null;
}

/* System throughput = actual combos processed / total node time across all jobs */
$total_combos_processed = $cpu['total_combos'] + $gpu['total_combos'];
$sys_throughput = ($total_node_secs > 0 && $total_combos_processed > 0)
    ? $total_combos_processed / $total_node_secs
    : 0.0; // H/s

/* ── Helper: format large combination counts ─────────────────────────────── */
function fmt_combinations(float $n): string {
    if ($n < 1e6)  return number_format($n, 0, ',', '.') . ' combinations';
    if ($n < 1e9)  return number_format($n / 1e6,  2, ',', '.') . ' M combinations';
    if ($n < 1e12) return number_format($n / 1e9,  2, ',', '.') . ' G combinations';
    if ($n < 1e15) return number_format($n / 1e12, 2, ',', '.') . ' T combinations';
    $exp  = (int)floor(log10($n));
    $mant = $n / pow(10, $exp);
    return number_format($mant, 2, ',', '') . ' &times; 10<sup>' . $exp . '</sup> combinations';
}

/* Helper: abbreviated SI-style combination count (K/M/G/T/P/E/Z/Y), always unit-suffixed
 * — no exponential fallback, complements fmt_combinations() for very large sample spaces. */
function fmt_combinations_short(float $n): string {
    $tiers = [
        1e24 => 'Y', 1e21 => 'Z', 1e18 => 'E', 1e15 => 'P',
        1e12 => 'T', 1e9  => 'G', 1e6  => 'M', 1e3  => 'K',
    ];
    foreach ($tiers as $threshold => $suffix) {
        if ($n >= $threshold) {
            return number_format($n / $threshold, 2, ',', '.') . ' ' . $suffix . ' combinations';
        }
    }
    return number_format($n, 0, ',', '.') . ' combinations';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JtR Cluster — Hash Report #<?= $hash['id'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../estilo.css?v=<?= filemtime(__DIR__ . '/../estilo.css') ?>">
</head>
<body>

<div class="page-header">
    <div class="d-flex align-items-center gap-3">
        <img src="../images/jtr_cluster_logo.png" alt="JtR Cluster" class="page-logo">
        <h1 class="h3 mb-0">
            <i class="bi bi-bar-chart-line-fill me-2 text-secondary"></i>
            Hash Report <span class="text-muted fw-normal">#<?= $hash['id'] ?></span>
        </h1>
    </div>

    <a href="index.php" class="btn btn-sm btn-outline-primary">← Back to admin</a>
</div>

<div class="container-fluid px-4 pb-5 report-container">

    <!-- ══════════════════════════════════════════════════════════════════════
         SECTION 1 — General hash information
    ══════════════════════════════════════════════════════════════════════ -->
    <div class="card report-section">
        <div class="card-header fw-semibold">
            <i class="bi bi-info-circle card-header-icon"></i>Hash information
        </div>
        <div class="card-body">
            <div class="row g-3">

                <div class="col-sm-6 col-md-3">
                    <div class="stat-label">Type</div>
                    <div class="stat-value">
                        <span class="badge bg-light text-dark border fs-6">
                            <?= htmlspecialchars($hash['hash_type']) ?>
                        </span>
                    </div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <div class="stat-label">Max password length</div>
                    <div class="stat-value"><?= $max_len ?> characters</div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <div class="stat-label">Submitted</div>
                    <div class="stat-value stat-value-sm">
                        <?= htmlspecialchars($hash['created_at']) ?>
                    </div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <div class="stat-label">Processing ended</div>
                    <div class="stat-value stat-value-sm">
                        <?= $hash['end_at'] ? htmlspecialchars($hash['end_at']) : '<span class="text-muted">—</span>' ?>
                    </div>
                </div>

                <div class="col-12">
                    <div class="stat-label">Hash</div>
                    <div class="hash-full bg-light rounded p-2 border">
                        <?= htmlspecialchars($hash['hash_text']) ?>
                    </div>
                    <?php if (!empty($hash['comment'])): ?>
                    <div class="stat-label mt-2">Comment</div>
                    <div class="text-muted small"><?= htmlspecialchars($hash['comment']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="col-sm-6">
                    <div class="stat-label">Password found</div>
                    <?php $cracked = $hash['result'] !== null && !in_array($hash['result'], ['NOT_FOUND', '']); ?>
                    <?php if ($cracked): ?>
                    <div class="stat-value text-success">
                        <?= htmlspecialchars(trim($hash['result'])) ?>
                    </div>
                    <?php else: ?>
                    <div class="stat-value text-secondary">
                        <span class="badge bg-secondary fs-6">Not found</span>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="col-sm-6">
                    <div class="stat-label">Character set</div>
                    <div class="stat-value stat-value-sm">
                        <?= htmlspecialchars($charset_name) ?>
                        <span class="stat-sub ms-1">(<?= $charset_size ?> chars)</span>
                    </div>
                </div>

                <div class="col-12">
                    <div class="stat-label">Password sample space</div>
                    <div class="stat-value stat-value-sm">
                        <?= fmt_combinations($sample_space) ?>
                        <span class="stat-sub ms-2" title="Abbreviated (SI-style) notation">
                            <?= fmt_combinations_short($sample_space) ?>
                        </span>
                        <span class="stat-sub ms-2">
                            (lengths 1–<?= $max_len ?>, charset size <?= $charset_size ?>)
                        </span>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- ══════════════════════════════════════════════════════════════════════
         SECTION 2 — Work distribution
    ══════════════════════════════════════════════════════════════════════ -->
    <div class="card report-section">
        <div class="card-header fw-semibold">
            <i class="bi bi-diagram-3 card-header-icon"></i>Work distribution
        </div>
        <div class="card-body">
            <?php
            $n_done      = (int)($dist['done']      ?? 0);
            $n_discarded = (int)($dist['discarded']  ?? 0);
            $n_pending   = (int)($dist['pending']    ?? 0);
            $n_splited   = (int)($dist['splited']    ?? 0);
            $n_joined    = (int)($dist['joined']     ?? 0);
            $n_total     = (int)($dist['total_quantums'] ?? 0);
            $n_effective = $n_total - $n_splited;

            $combos_done      = (float)($coverage['combos_done']      ?? 0);
            $combos_discarded = (float)($coverage['combos_discarded'] ?? 0);
            $combos_pending   = (float)($coverage['combos_pending']   ?? 0);
            $combos_total     = (float)($coverage['combos_total']     ?? 0);

            $pct_done      = $combos_total > 0 ? round($combos_done      * 100 / $combos_total) : 0;
            $pct_discarded = $combos_total > 0 ? round($combos_discarded * 100 / $combos_total) : 0;
            $pct_pending   = $combos_total > 0 ? (100 - $pct_done - $pct_discarded)             : 0;
            ?>
            <div class="row g-3">

                <div class="col-sm-3">
                    <div class="stat-label">Done</div>
                    <div class="stat-value text-primary"><?= number_format($n_done, 0, ',', '.') ?></div>
                    <div class="stat-sub">Executed by a node (found + not found)</div>
                </div>

                <div class="col-sm-3">
                    <div class="stat-label">Discarded</div>
                    <div class="stat-value text-warning"><?= number_format($n_discarded, 0, ',', '.') ?></div>
                    <div class="stat-sub">Cancelled in cascade when password was found</div>
                </div>

                <div class="col-sm-3">
                    <div class="stat-label">Pending</div>
                    <div class="stat-value text-secondary"><?= number_format($n_pending, 0, ',', '.') ?></div>
                    <div class="stat-sub">Still queued, not yet assigned</div>
                </div>

                <?php if ($combos_total > 0): ?>
                <div class="col-12">
                    <div class="stat-label">Search coverage</div>
                    <div class="progress mt-1 progress-report">
                        <div class="progress-bar bg-primary pct-bar"
                             style="--pct:<?= $pct_done ?>%"
                             title="Done: <?= $pct_done ?>%">
                            <?php if ($pct_done >= 8): ?><?= $pct_done ?>%<?php endif; ?>
                        </div>
                        <?php if ($pct_discarded > 0): ?>
                        <div class="progress-bar bg-warning progress-bar-discarded pct-bar"
                             style="--pct:<?= $pct_discarded ?>%"
                             title="Discarded: <?= $pct_discarded ?>%">
                        </div>
                        <?php endif; ?>
                        <?php if ($pct_pending > 0): ?>
                        <div class="progress-bar bg-secondary progress-bar-pending pct-bar"
                             style="--pct:<?= $pct_pending ?>%"
                             title="Pending: <?= $pct_pending ?>%">
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="stat-sub mt-1 d-flex gap-3 flex-wrap">
                        <span><span class="badge bg-primary">&nbsp;</span> Done <?= $pct_done ?>%</span>
                        <?php if ($n_discarded > 0): ?>
                        <span><span class="badge bg-warning">&nbsp;</span> Discarded <?= $pct_discarded ?>%</span>
                        <?php endif; ?>
                        <?php if ($n_pending > 0): ?>
                        <span><span class="badge bg-secondary">&nbsp;</span> Pending <?= $pct_pending ?>%</span>
                        <?php endif; ?>
                        <span class="ms-auto"><?= number_format($n_effective, 0, ',', '.') ?> total quantums</span>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (!empty($level_rows)): ?>
                <div class="col-12 mt-3">
                    <div class="stat-label mb-2">Jobs</div>
                    <table class="table table-sm table-bordered mb-0 level-dist-table">
                        <thead class="table-light">
                            <tr>
                                <th class="text-end">Total</th>
                                <th class="text-end">Pending</th>
                                <th class="text-end">Processing</th>
                                <th class="text-end">Done</th>
                                <th class="text-end">Discarded</th>
                                <th class="text-end">Avg time</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($level_rows as $lr): ?>
                            <tr>
                                <td class="text-end fw-semibold"><?= number_format((int)$lr['total'], 0, ',', '.') ?></td>
                                <td class="text-end <?= (int)$lr['pending']    > 0 ? 'text-secondary' : 'text-muted' ?>">
                                    <?= number_format((int)$lr['pending'], 0, ',', '.') ?>
                                </td>
                                <td class="text-end <?= (int)$lr['processing'] > 0 ? 'text-primary'   : 'text-muted' ?>">
                                    <?= number_format((int)$lr['processing'], 0, ',', '.') ?>
                                </td>
                                <td class="text-end <?= (int)$lr['done']       > 0 ? 'text-success'   : 'text-muted' ?>">
                                    <?= number_format((int)$lr['done'], 0, ',', '.') ?>
                                </td>
                                <td class="text-end <?= (int)$lr['discarded']  > 0 ? 'text-warning'   : 'text-muted' ?>">
                                    <?= number_format((int)$lr['discarded'], 0, ',', '.') ?>
                                </td>
                                <td class="text-end text-muted small">
                                    <?= $lr['avg_secs'] !== null
                                        ? fmt_duration((int)round((float)$lr['avg_secs']))
                                        : '—' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <!-- ══════════════════════════════════════════════════════════════════════
         SECTION 3 — Per-node-type statistics
    ══════════════════════════════════════════════════════════════════════ -->
    <div class="card report-section">
        <div class="card-header fw-semibold">
            <i class="bi bi-cpu card-header-icon"></i>Node statistics
        </div>
        <div class="card-body">
            <div class="row g-0">

                <!-- CPU -->
                <div class="col-sm-6 <?= (int)$gpu['jobs'] > 0 ? 'border-end pe-4' : '' ?> pb-3 pb-sm-0">
                    <h6 class="fw-semibold mb-3">
                        <i class="bi bi-cpu-fill me-1 text-info"></i>CPU
                    </h6>
                    <?php if ((int)($cpu['jobs'] ?? 0) === 0): ?>
                    <p class="text-muted mb-0">No CPU jobs for this hash.</p>
                    <?php else: ?>
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="stat-label">Jobs processed</div>
                            <div class="stat-value"><?= number_format((int)$cpu['jobs'], 0, ',', '.') ?></div>
                        </div>
                        <div class="col-6">
                            <div class="stat-label">Distinct devices</div>
                            <div class="stat-value"><?= (int)$cpu['nodes'] ?></div>
                        </div>
                        <div class="col-6">
                            <div class="stat-label">Avg. time / job</div>
                            <div class="stat-value">
                                <?= $cpu['avg_secs'] !== null
                                    ? fmt_duration((int)round((float)$cpu['avg_secs']))
                                    : '<span class="text-muted">—</span>' ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="stat-label">Avg. throughput / job</div>
                            <div class="stat-value">
                                <?= $cpu['avg_throughput'] > 0
                                    ? number_format($cpu['avg_throughput'] / 1e9, 3, ',', '.') . ' <small class="text-muted">GH/s</small>'
                                    : '<span class="text-muted">—</span>' ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- GPU -->
                <div class="col-sm-6 <?= (int)$cpu['jobs'] > 0 ? 'ps-sm-4' : '' ?> pt-3 pt-sm-0">
                    <h6 class="fw-semibold mb-3">
                        <i class="bi bi-gpu-card me-1 text-warning"></i>GPU
                    </h6>
                    <?php if ((int)($gpu['jobs'] ?? 0) === 0): ?>
                    <p class="text-muted mb-0">No GPU jobs for this hash.</p>
                    <?php else: ?>
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="stat-label">Jobs processed</div>
                            <div class="stat-value"><?= number_format((int)$gpu['jobs'], 0, ',', '.') ?></div>
                        </div>
                        <div class="col-6">
                            <div class="stat-label">Distinct devices</div>
                            <div class="stat-value"><?= (int)$gpu['nodes'] ?></div>
                        </div>
                        <div class="col-6">
                            <div class="stat-label">Avg. time / job</div>
                            <div class="stat-value">
                                <?= $gpu['avg_secs'] !== null
                                    ? fmt_duration((int)round((float)$gpu['avg_secs']))
                                    : '<span class="text-muted">—</span>' ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="stat-label">Avg. throughput / job</div>
                            <div class="stat-value">
                                <?= $gpu['avg_throughput'] > 0
                                    ? number_format($gpu['avg_throughput'] / 1e9, 3, ',', '.') . ' <small class="text-muted">GH/s</small>'
                                    : '<span class="text-muted">—</span>' ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

            </div>

            <?php if (!empty($cpu_breakdown)): ?>
            <div class="mt-4 pt-3 border-top">
                <div class="stat-label mb-2">CPU breakdown
                    <small class="text-muted fw-normal ms-1 text-hint-xs">
                        — one row per node, aggregating all jobs processed by that node's CPU cores
                    </small>
                </div>
                <table class="table table-sm table-bordered mb-0 level-dist-table">
                    <thead class="table-light">
                        <tr>
                            <th>Node</th>
                            <th>CPUs used</th>
                            <th class="text-end">Jobs</th>
                            <th class="text-end">Avg. time / job</th>
                            <th class="text-end" title="Throughput while actively processing jobs (idle time between jobs not counted)">Throughput when active</th>
                            <th class="text-end" title="Effective contribution to system throughput = throughput when active × utilization">Effective GH/s</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($cpu_breakdown as $cr):
                        $util_pct    = ($wall_clock_secs > 0 && $cr['sum_secs'] > 0)
                                       ? min(100, round((int)$cr['sum_secs'] / $wall_clock_secs * 100, 1))
                                       : null;
                        $effective_ghs = ($cr['ghs'] !== null && $util_pct !== null)
                                       ? round((float)$cr['ghs'] * $util_pct / 100, 3)
                                       : null;
                    ?>
                        <tr>
                            <td class="text-muted small"><?= htmlspecialchars($cr['ip']) ?></td>
                            <td class="small">
                                <code><?= (int)$cr['cpu_count'] ?> CPU<?= (int)$cr['cpu_count'] !== 1 ? 's' : '' ?></code>
                            </td>
                            <td class="text-end"><?= number_format((int)$cr['jobs'], 0, ',', '.') ?></td>
                            <td class="text-end text-muted small"><?= fmt_duration((int)$cr['avg_secs']) ?></td>
                            <td class="text-end fw-semibold">
                                <?= $cr['ghs'] !== null
                                    ? number_format((float)$cr['ghs'], 3, ',', '.') . ' <small class="text-muted">GH/s</small>'
                                    : '—' ?>
                            </td>
                            <td class="text-end fw-semibold">
                                <?= $effective_ghs !== null
                                    ? number_format($effective_ghs, 3, ',', '.') . ' <small class="text-muted">GH/s</small>'
                                    : '—' ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p class="text-muted small mt-2 mb-0">
                    <i class="bi bi-info-circle me-1"></i>
                    <strong>Throughput when active</strong> measures the combined node speed only while its cores were processing jobs
                    (idle time between jobs is excluded). <strong>Effective GH/s</strong> = throughput when active × utilization,
                    and its sum across all nodes equals the system throughput shown below.
                </p>
            </div>
            <?php endif; ?>

            <?php if (!empty($gpu_breakdown)): ?>
            <div class="mt-4 pt-3 border-top">
                <div class="stat-label mb-2">GPU breakdown
                    <small class="text-muted fw-normal ms-1 text-hint-xs">
                        — throughput measured only during active processing; see Effective GH/s for wall-clock contribution
                    </small>
                </div>
                <table class="table table-sm table-bordered mb-0 level-dist-table">
                    <thead class="table-light">
                        <tr>
                            <th>Node</th>
                            <th>GPU</th>
                            <th class="text-end">Jobs</th>
                            <th class="text-end">Avg. time / job</th>
                            <th class="text-end" title="Throughput while actively processing a job (idle time between jobs not counted)">Throughput when active</th>
                            <th class="text-end" title="Effective contribution to system throughput = throughput when active × utilization">Effective GH/s</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($gpu_breakdown as $gr):
                        $util_pct    = ($wall_clock_secs > 0 && $gr['sum_secs'] > 0)
                                       ? min(100, round((int)$gr['sum_secs'] / $wall_clock_secs * 100, 1))
                                       : null;
                        $effective_ghs = ($gr['ghs'] !== null && $util_pct !== null)
                                       ? round((float)$gr['ghs'] * $util_pct / 100, 3)
                                       : null;
                    ?>
                        <tr>
                            <td class="text-muted small"><?= htmlspecialchars($gr['ip']) ?></td>
                            <td class="small">
                                <code>GPU-<?= (int)$gr['device_id'] ?></code>
                                <span class="text-muted ms-1"><?= htmlspecialchars($gr['model']) ?></span>
                            </td>
                            <td class="text-end"><?= number_format((int)$gr['jobs'], 0, ',', '.') ?></td>
                            <td class="text-end text-muted small"><?= fmt_duration((int)$gr['avg_secs']) ?></td>
                            <td class="text-end fw-semibold">
                                <?= $gr['ghs'] !== null
                                    ? number_format((float)$gr['ghs'], 3, ',', '.') . ' <small class="text-muted">GH/s</small>'
                                    : '—' ?>
                            </td>
                            <td class="text-end fw-semibold">
                                <?= $effective_ghs !== null
                                    ? number_format($effective_ghs, 3, ',', '.') . ' <small class="text-muted">GH/s</small>'
                                    : '—' ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p class="text-muted small mt-2 mb-0">
                    <i class="bi bi-info-circle me-1"></i>
                    <strong>Throughput when active</strong> measures the device speed only while it was processing a job
                    (idle time between jobs is excluded). <strong>Effective GH/s</strong> = throughput when active × utilization,
                    and its sum across all devices equals the system throughput shown below.
                </p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ══════════════════════════════════════════════════════════════════════
         SECTION 4 — Timing & system performance
    ══════════════════════════════════════════════════════════════════════ -->
    <div class="card report-section">
        <div class="card-header fw-semibold">
            <i class="bi bi-stopwatch card-header-icon"></i>Timing &amp; performance
        </div>
        <div class="card-body">

            <div class="row g-0">

                <!-- Col 1 -->
                <div class="col-6 border-end pe-4">
                    <h6 class="fw-semibold mb-3">
                        <i class="bi bi-clock me-1 text-secondary"></i>Wall-clock time
                    </h6>
                    <div class="stat-value mb-1">
                        <?= $wall_clock_secs !== null
                            ? fmt_duration($wall_clock_secs)
                            : '<span class="text-muted">—</span>' ?>
                    </div>
                    <div class="stat-sub mb-4">End of processing − submission date</div>

                    <div class="stat-label">System throughput</div>
                    <div class="stat-value">
                        <?php
                        $combos_done_wall = (float)($coverage['combos_done'] ?? 0);
                        if ($wall_clock_secs !== null && $wall_clock_secs > 0 && $combos_done_wall > 0): ?>
                            <?= number_format(($combos_done_wall / $wall_clock_secs) / 1e9, 3, ',', '.') ?>
                            <small class="text-muted">GH/s</small>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </div>
                    <div class="stat-sub">
                        All combinations (CPU + GPU) ÷ wall-clock time.<br>
                        Includes idle gaps between jobs — lower than the sum of individual GPU throughputs,
                        which only measure speed <em>while actively processing</em>.
                    </div>
                </div>

                <!-- Col 2 -->
                <div class="col-6 ps-4">
                    <h6 class="fw-semibold mb-3">
                        <i class="bi bi-clock-history me-1 text-secondary"></i>Total processing node time
                    </h6>
                    <div class="stat-value mb-1">
                        <?= $total_node_secs > 0
                            ? fmt_duration($total_node_secs)
                            : '<span class="text-muted">—</span>' ?>
                    </div>
                    <div class="stat-sub mb-4">Sum of all job durations across nodes</div>
                </div>


            </div>
        </div>
    </div>

</div><!-- /container -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
