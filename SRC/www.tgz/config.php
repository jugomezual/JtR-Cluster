<?php
/*
 * config.php — Database connection parameters.
 *
 * Edit this file to change the database host, credentials, or name.
 * Loaded by includes/bd-connect.php before opening the connection.
 */

// -- Database ------------------------------------------------------------
define('DB_HOST',    'localhost');
define('DB_USER',    'jtrcluster');
define('DB_PASS',    'CHANGE_ME');
define('DB_NAME',    'jtrcluster');
define('DB_CHARSET', 'utf8');

// -- File uploads ----------------------------------------------------------
define('UPLOAD_DIR',        __DIR__ . '/uploads/');
define('UPLOAD_MAX_BYTES',  5 * 1024 * 1024);          // 5 MB
define('UPLOAD_EXTENSIONS', ['pdf', 'zip', 'doc', 'docx', 'rar', '7z']);

// -- Logging -----------------------------------------------------------------
define('SUBMIT_LOG', __DIR__ . '/log.txt');
