<?php
session_start();
require_once __DIR__ . '/includes/includes.php';

// Configuration is defined in config.php (loaded via includes/includes.php):
//   UPLOAD_DIR, UPLOAD_MAX_BYTES, UPLOAD_EXTENSIONS, SUBMIT_LOG

function setMessage(string $message, string $type): void {
    $_SESSION['message']      = $message;
    $_SESSION['message_type'] = $type;
}

function redirectToIndex(): never {
    header('Location: index.php');
    exit;
}

function sanitizeFilename(string $filename): string {
    $filename = preg_replace("/[^a-zA-Z0-9._-]/", "_", $filename);
    if (strpos($filename, '.') === 0) {
        $filename = '_' . substr($filename, 1);
    }
    return $filename;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Access not allowed.', 'error');
    redirectToIndex();
}

$hashString  = isset($_POST['hash_string']) ? trim($_POST['hash_string']) : '';
$hashType    = isset($_POST['hash_type'])   ? $_POST['hash_type']         : '';
$email       = isset($_POST['email'])       ? trim($_POST['email'])        : '';
$comment     = isset($_POST['comment'])     ? substr(trim($_POST['comment']), 0, 255) : '';
$validationError  = false;
$uploadedFileInfo = null;
$filePresent = isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK;
$hashPresent = $hashString !== '' && $hashType !== '';

// --- Validate email ---
if ($email === '') {
    setMessage('Email address is required.', 'error');
    $validationError = true;
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    setMessage('Invalid email address format.', 'error');
    $validationError = true;
}

// --- Require hash or file ---
if (!$validationError && !$hashPresent && !$filePresent) {
    setMessage('You must enter a hash (with its type) or upload a file.', 'error');
    $validationError = true;
}

// --- Validate hash ---
if (!$validationError && $hashPresent) {
    if ($hashString === '') {
        setMessage('Hash string is required when a hash type is selected.', 'error');
        $validationError = true;
    }
    if (!$validationError && $hashType === '') {
        setMessage('Hash type is required when a hash string is entered.', 'error');
        $validationError = true;
    }
    if (!$validationError) {
        switch ($hashType) {
            case 'MD5':
            case 'SHA1':
            case 'SHA256':
            case 'SHA512':
                $charsOk = ctype_xdigit($hashString);
                break;
            case 'BCRYPT':
                $charsOk = true;
                break;
            default:
                $charsOk = true;
                break;
        }

        $lengthOk = false;
        switch ($hashType) {
            case 'MD5':    $lengthOk = strlen($hashString) == 32;  break;
            case 'SHA1':   $lengthOk = strlen($hashString) == 40;  break;
            case 'SHA256': $lengthOk = strlen($hashString) == 64;  break;
            case 'SHA512': $lengthOk = strlen($hashString) == 128; break;
            case 'BCRYPT':
                $lengthOk = (strlen($hashString) >= 59 && strlen($hashString) <= 61)
                            && preg_match('/^\$2[aby]\$.{56,}$/', $hashString);
                break;
            default:
                setMessage('Selected hash type is not valid.', 'error');
                $validationError = true;
                break;
        }

        if (!$validationError && !$lengthOk) {
            setMessage("Hash length does not match type '$hashType'.", 'error');
            $validationError = true;
        }
        if (!$validationError && !$charsOk) {
            setMessage('Hash string contains invalid characters.', 'error');
            $validationError = true;
        }
    }
}

// --- Validate charset and password length ---
$charsetId = isset($_POST['charset']) ? $_POST['charset'] : '';
if ($charsetId === '') {
    setMessage('You must select a character set.', 'error');
    $validationError = true;
} elseif (!in_array($charsetId, ['0','1','2','3','4'])) {
    setMessage('Invalid character set option.', 'error');
    $validationError = true;
}

$passwordLength = isset($_POST['password_length']) ? (int) $_POST['password_length'] : 0;
if ($passwordLength < 4 || $passwordLength > 15) {
    setMessage('Password length must be between 4 and 15 characters.', 'error');
    $validationError = true;
}

if ($validationError) {
    $_SESSION['form_data_hash_string'] = $hashString;
    $_SESSION['form_data_hash_type']   = $hashType;
    $_SESSION['form_data_email']       = $email;
    $_SESSION['form_data_comment']     = $comment;
    redirectToIndex();
}

// --- Handle uploaded file ---
$finalFilename = null;
if ($filePresent) {
    $file         = $_FILES['archivo'];
    $originalName = $file['name'];
    $fileSize     = $file['size'];
    $tmpPath      = $file['tmp_name'];
    $extension    = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    if ($fileSize > UPLOAD_MAX_BYTES) {
        setMessage('File too large. Limit: 5 MB.', 'error');
        $validationError = true;
    }
    if (!$validationError && !in_array($extension, UPLOAD_EXTENSIONS)) {
        setMessage('File type not allowed.', 'error');
        $validationError = true;
    }

    if (!$validationError) {
        if (!is_dir(UPLOAD_DIR)) {
            mkdir(UPLOAD_DIR, 0775, true);
            file_put_contents(UPLOAD_DIR . '.htaccess', "Options -Indexes\nDeny from all");
        }
        if (!is_writable(UPLOAD_DIR)) {
            setMessage('Upload directory is not writable.', 'error');
            $validationError = true;
        }

        if (!$validationError) {
            $safeName      = sanitizeFilename($originalName);
            $finalFilename = uniqid() . '_' . $safeName;
            $destPath      = UPLOAD_DIR . $finalFilename;

            if (!move_uploaded_file($tmpPath, $destPath)) {
                setMessage('Failed to move the uploaded file.', 'error');
                $validationError = true;
            } else {
                $uploadedFileInfo = [
                    'original_name' => $originalName,
                    'saved_name'    => $finalFilename,
                    'storage_path'  => realpath($destPath),
                    'size_bytes'    => $fileSize,
                    'extension'     => $extension,
                ];
            }
        }
    }
}

// --- Save to database ---
if (!$validationError) {
    // Check for duplicate hash
    if ($hashString !== '') {
        $existing = hashes_find_by_text($db, $hashString);

        if ($existing !== null) {
            // Log the request regardless of hash state
            $logData = [
                'timestamp'   => date('Y-m-d H:i:s'),
                'email'       => $email,
                'hash_type'   => $hashType,
                'hash_string' => $hashString,
                'note'        => $existing['result'] !== null ? 'duplicate_result_resent' : 'duplicate_pending',
            ];
            file_put_contents(SUBMIT_LOG, json_encode($logData) . PHP_EOL, FILE_APPEND | LOCK_EX);

            if ($existing['result'] !== null) {
                // Already cracked — send result to the requester's email
                hashes_notify_cracked($email, $hashString, $existing['result']);
                setMessage('This hash has already been cracked. The result has been sent to your email address.', 'success');
            } else {
                // Exists but still pending/processing
                setMessage('This hash is already registered and is being processed. You will be notified by email when the result is available.', 'success');
            }
            redirectToIndex();
        }
    }

    try {
        $insertedId = hashes_insert(
            $db,
            $hashType,
            (int)$charsetId,
            $email,
            $passwordLength,
            $hashString !== '' ? $hashString : null,
            $finalFilename,
            $comment !== '' ? $comment : null
        );
    } catch (RuntimeException $e) {
        setMessage('Error saving record to the database: ' . $e->getMessage(), 'error');
        $_SESSION['form_data_hash_string'] = $hashString;
        $_SESSION['form_data_hash_type']   = $hashType;
        $_SESSION['form_data_email']       = $email;
        $_SESSION['form_data_comment']     = $comment;
        redirectToIndex();
    }

    // Extract hash from uploaded file (updates DB)
    if ($filePresent && $finalFilename) {
        $cmd = escapeshellcmd("/jtr-cluster/www/bin/extraer_hash $insertedId");
        shell_exec($cmd . ' > /jtr-cluster/www/extraer_hash.log 2>&1');
    }

    // Generate job quanta
    jobs_generate_quantums($db, $insertedId);
}

// --- Append to log ---
$logData = [
    'timestamp'     => date('Y-m-d H:i:s'),
    'email'         => $email,
    'hash_type'     => $hashType,
    'hash_string'   => $hashString,
    'file_uploaded' => $uploadedFileInfo ? 'yes' : 'no',
    'charset'       => "charset:$charsetId",
    'file_details'  => $uploadedFileInfo ?? 'N/A',
];
file_put_contents(SUBMIT_LOG, json_encode($logData) . PHP_EOL, FILE_APPEND | LOCK_EX);

// --- Success message ---
if (!$validationError) {
    if ($uploadedFileInfo) {
        setMessage(
            "Done. Hash registered and file '" . htmlspecialchars($uploadedFileInfo['original_name'])
            . "' saved as '" . htmlspecialchars($uploadedFileInfo['saved_name']) . "'.",
            'success'
        );
    } else {
        setMessage('Done. Hash registered successfully.', 'success');
    }
}

redirectToIndex();
