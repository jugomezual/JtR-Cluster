<?php
session_start();
require_once __DIR__ . '/includes/includes.php';
$session_message = '';
$session_message_type = '';
if (isset($_SESSION['message'])) {
    $session_message = htmlspecialchars($_SESSION['message']);
    $session_message_type = htmlspecialchars($_SESSION['message_type']);
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

$form_data_hash_string = isset($_SESSION['form_data_hash_string']) ? htmlspecialchars($_SESSION['form_data_hash_string']) : '';
$form_data_hash_type   = isset($_SESSION['form_data_hash_type'])   ? htmlspecialchars($_SESSION['form_data_hash_type'])   : '';
$form_data_email       = isset($_SESSION['form_data_email'])       ? htmlspecialchars($_SESSION['form_data_email'])       : '';
$form_data_comment     = isset($_SESSION['form_data_comment'])     ? htmlspecialchars($_SESSION['form_data_comment'])     : '';

unset($_SESSION['form_data_hash_string']);
unset($_SESSION['form_data_hash_type']);
unset($_SESSION['form_data_email']);
unset($_SESSION['form_data_comment']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JtR Cluster — Hash &amp; File Processor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="estilo.css?v=<?= filemtime(__DIR__ . '/estilo.css') ?>">
</head>
<body>

<div class="page-header">
    <img src="images/jtr_cluster_logo.png" alt="JtR Cluster" class="page-logo">
    <a href="admin/" class="btn btn-sm btn-outline-primary">Admin panel →</a>
</div>

<div class="form-wrapper">
    <h2 class="h5 mb-4 fw-semibold">Submit a hash or a file — not both</h2>

    <?php if (!empty($session_message)): ?>
        <div class="flash-<?= $session_message_type === 'success' ? 'success' : 'error' ?>">
            <?= $session_message ?>
        </div>
    <?php endif; ?>

    <form action="procesar.php" method="post" enctype="multipart/form-data">

        <fieldset>
            <legend>Hash or a file</legend>

            <div class="form-subgroup">
                <div class="form-subgroup-title">Hash string</div>
                <div class="form-subgroup-body">
                    <label class="form-label fw-semibold" for="hash_string">Hash</label>
                    <input type="text" class="form-control mb-3" id="hash_string" name="hash_string"
                           value="<?= $form_data_hash_string ?>"
                           placeholder="e.g. 5f4dcc3b5aa765d61d8327deb882cf99">

                    <label class="form-label fw-semibold" for="hash_type">Hash type</label>
                    <select class="form-select" id="hash_type" name="hash_type">
                        <option value="" <?= empty($form_data_hash_type) ? 'selected' : '' ?>>— Select a type if entering a hash —</option>
                        <option value="MD5"    <?= $form_data_hash_type == 'MD5'    ? 'selected' : '' ?>>MD5</option>
                        <option value="SHA1"   <?= $form_data_hash_type == 'SHA1'   ? 'selected' : '' ?>>SHA-1</option>
                        <option value="SHA256" <?= $form_data_hash_type == 'SHA256' ? 'selected' : '' ?>>SHA-256</option>
                        <option value="SHA512" <?= $form_data_hash_type == 'SHA512' ? 'selected' : '' ?>>SHA-512</option>
                        <option value="BCRYPT" <?= $form_data_hash_type == 'BCRYPT' ? 'selected' : '' ?>>bcrypt</option>
                    </select>
                </div>
            </div>

            <div class="form-or-divider"><span>OR</span></div>

            <div class="form-subgroup">
                <div class="form-subgroup-title">File</div>
                <div class="form-subgroup-body">
                    <label class="form-label fw-semibold" for="archivo">Upload a file <span class="text-muted fw-normal">(PDF, DOC, DOCX, ZIP, RAR, 7Z)</span></label>
                    <div class="file-input-wrapper form-control">
                        <button type="button" class="file-input-button">Choose file</button>
                        <span class="file-input-name">No file chosen</span>
                        <input type="file" id="archivo" name="archivo" class="visually-hidden">
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset>
            <legend>Search parameters</legend>

            <label class="form-label fw-semibold" for="charset">Character set</label>
            <select class="form-select mb-3" name="charset" id="charset" required>
                <option value="0">Digits only (0–9)</option>
                <option value="1">Lowercase letters (a–z)</option>
                <option value="2">Uppercase letters (A–Z)</option>
                <option value="3">Letters &amp; digits (A–Z, a–z, 0–9)</option>
                <option value="4">All printable ASCII characters</option>
            </select>

            <label class="form-label fw-semibold" for="password_length">Maximum password length</label>
            <input type="number" class="form-control mb-1" id="password_length" name="password_length"
                   min="4" max="15" step="1" required placeholder="Between 4 and 15"
                   onkeydown="return ['Backspace','Delete','ArrowLeft','ArrowRight','Tab'].includes(event.key) || /^[0-9]$/.test(event.key)"
                   oninput="this.value = this.value.replace(/[^0-9]/g, '')">
            <span class="field-hint">Combinations will be generated from 4 up to the specified length. Max: 15.</span>
        </fieldset>

        <fieldset>
            <legend>Contact information</legend>
            <label class="form-label fw-semibold" for="email">Email address</label>
            <input type="email" class="form-control mb-3" id="email" name="email"
                   value="<?= $form_data_email ?>" required
                   placeholder="you@example.com">
            <label class="form-label fw-semibold" for="comment">
                Comment
                <span class="text-muted fw-normal">(optional, max 255 characters)</span>
            </label>
            <input type="text" class="form-control mb-1" id="comment" name="comment"
                   value="<?= $form_data_comment ?>" maxlength="255"
                   placeholder="e.g. Office document from 2023">
            <span class="field-hint" id="comment-counter">0 / 255</span>
        </fieldset>

        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Process</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    const input   = document.getElementById('comment');
    const counter = document.getElementById('comment-counter');
    function update() { counter.textContent = input.value.length + ' / 255'; }
    input.addEventListener('input', update);
    update();
})();

(function () {
    const fileInput = document.getElementById('archivo');
    const button    = document.querySelector('.file-input-button');
    const nameSpan  = document.querySelector('.file-input-name');
    button.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => {
        nameSpan.textContent = fileInput.files.length ? fileInput.files[0].name : 'No file chosen';
    });
})();
</script>
</body>
</html>
