<?php
/*
 * POST /api/node/result
 *
 * Body: {
 *   "job_id":  <int>,
 *   "found":   true|false,
 *   "password": "<string>",
 *   "hash_id": "<int-as-string>",
 *   "node_ip": "<ip>",
 *   "id_gpu":  <int>   (or absent),
 *   "id_cpu":  <int>   (or absent)
 * }
 *
 * Response: { "status": "ok" } or { "error": "..." }
 */

require_once __DIR__ . '/../../includes/includes.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);

if (!$body || !isset($body['job_id'], $body['found'], $body['password'], $body['hash_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

$job_id   = (int)$body['job_id'];
$found    = (bool)$body['found'];
$password = (string)$body['password'];
$hash_id  = (int)$body['hash_id'];
$node_ip  = (string)($body['node_ip'] ?? '');
$gpu_dev  = isset($body['id_gpu']) ? (int)$body['id_gpu'] : -1;
$cpu_dev  = isset($body['id_cpu']) ? (int)$body['id_cpu'] : -1;

/* ── 1. Check job is still in 'processing' state ─────────────────────── */
$stmt = $db->prepare("SELECT 1 FROM jobs WHERE id=? AND status='processing'");
$stmt->bind_param('i', $job_id);
$stmt->execute();
$job_meta = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$job_meta) {
    /* Job was not in 'processing' state — nothing more to do */
    echo json_encode(['status' => 'ok']);
    exit;
}

/* ── 2. Update primary job status ────────────────────────────────────── */
if ($found) {
    $stmt = $db->prepare(
        "UPDATE jobs SET status='found', result=?, completed_at=NOW()
         WHERE id=? AND status='processing'"
    );
    $stmt->bind_param('si', $password, $job_id);
} else {
    $stmt = $db->prepare(
        "UPDATE jobs SET status='not_found', completed_at=NOW()
         WHERE id=? AND status='processing'"
    );
    $stmt->bind_param('i', $job_id);
}
$stmt->execute();
$job_updated = $stmt->affected_rows;
$stmt->close();

if ($job_updated < 1) {
    echo json_encode(['status' => 'ok']);
    exit;
}

/* ── 3. Free the device ───────────────────────────────────────────────── */
if ($gpu_dev >= 0) {
    $stmt = $db->prepare(
        "UPDATE gpus SET status='free'
         WHERE node_id=(SELECT id FROM nodes WHERE ip=?) AND device_id=?"
    );
    $stmt->bind_param('si', $node_ip, $gpu_dev);
    $stmt->execute();
    $stmt->close();
}
if ($cpu_dev >= 0) {
    $stmt = $db->prepare(
        "UPDATE cpus SET status='free'
         WHERE node_id=(SELECT id FROM nodes WHERE ip=?) AND device_id=?"
    );
    $stmt->bind_param('si', $node_ip, $cpu_dev);
    $stmt->execute();
    $stmt->close();
}

/* ── 4. Get email for this hash ──────────────────────────────────────── */
$stmt = $db->prepare("SELECT email, hash_text, result FROM hashes WHERE id=?");
$stmt->bind_param('i', $hash_id);
$stmt->execute();
$hrow = $stmt->get_result()->fetch_assoc();
$stmt->close();

$email     = $hrow['email']     ?? '';
$hash_text = $hrow['hash_text'] ?? '';

/* ── 5a. Password found ──────────────────────────────────────────────── */
if ($found) {
    /* Cancel all remaining pending/processing jobs for this hash */
    $stmt = $db->prepare(
        "UPDATE jobs SET status='discarded', completed_at=NOW()
         WHERE hash_id=? AND status IN ('pending','processing')"
    );
    $stmt->bind_param('i', $hash_id);
    $stmt->execute();
    $stmt->close();

    /* Only update hashes if not already cracked */
    $existing = $hrow['result'] ?? '';
    if ($existing === '' || $existing === null || $existing === 'NOT_FOUND') {
        $stmt = $db->prepare(
            "UPDATE hashes SET result=?, completed_at=NOW() WHERE id=?"
        );
        $stmt->bind_param('si', $password, $hash_id);
        $stmt->execute();
        $stmt->close();

        if ($email !== '') {
            hashes_notify_cracked($email, $hash_text, $password);
        }
    }

/* ── 5b. Not found — check if all jobs exhausted ─────────────────────── */
} else {
    $stmt = $db->prepare(
        "SELECT
            SUM(j.status='pending')    AS pending,
            SUM(j.status='processing') AS processing,
            h.result
         FROM hashes h
         LEFT JOIN jobs j ON j.hash_id = h.id
         WHERE h.id = ?
         GROUP BY h.id"
    );
    $stmt->bind_param('i', $hash_id);
    $stmt->execute();
    $check = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $pending    = (int)($check['pending']    ?? 0);
    $processing = (int)($check['processing'] ?? 0);
    $cur_result = $check['result'] ?? '';

    $result_empty = ($cur_result === '' || $cur_result === null);
    $has_password = ($cur_result !== '' && $cur_result !== null && $cur_result !== 'NOT_FOUND');

    if (!$has_password && $pending === 0 && $processing === 0 && $result_empty) {
        $stmt = $db->prepare(
            "UPDATE hashes SET result='NOT_FOUND', completed_at=NOW() WHERE id=?"
        );
        $stmt->bind_param('i', $hash_id);
        $stmt->execute();
        $stmt->close();

        if ($email !== '') {
            hashes_notify_not_found($email, $hash_text);
        }
    }
}

echo json_encode(['status' => 'ok']);
