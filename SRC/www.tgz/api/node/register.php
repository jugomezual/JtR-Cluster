<?php
/*
 * POST /api/node/register
 *
 * Body: {
 *   "ip": "10.0.1.x",
 *   "gpus": [ { "device_id", "model", "perf_info", "throughput", "status" }, ... ],
 *   "cpus": [ { "device_id", "model", "perf_info", "throughput", "status" }, ... ]
 * }
 * One request per device type (GPU or CPU) — matches hw_register_node() behaviour.
 *
 * Response: { "status": "ok", "node_id": <int> }
 */

require_once __DIR__ . '/../../includes/includes.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
if (!$body || !isset($body['ip'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON or missing ip']);
    exit;
}

$ip      = trim($body['ip']);
$has_gpu = !empty($body['gpus']) ? 1 : 0;
$has_cpu = !empty($body['cpus']) ? 1 : 0;

/* ── 1. Upsert node ─────────────────────────────────────────────────── */
$stmt = $db->prepare(
    "INSERT INTO nodes (ip, has_gpu, has_cpu) VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE
     has_gpu = has_gpu | VALUES(has_gpu),
     has_cpu = has_cpu | VALUES(has_cpu)"
);
$stmt->bind_param('sii', $ip, $has_gpu, $has_cpu);
$stmt->execute();
$stmt->close();

$stmt = $db->prepare("SELECT id FROM nodes WHERE ip = ?");
$stmt->bind_param('s', $ip);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    http_response_code(500);
    echo json_encode(['error' => 'Node upsert failed']);
    exit;
}
$node_id = (int)$row['id'];

/* ── 1b. Reset stale jobs and free devices for this node on startup ─── */
$stmt = $db->prepare(
    "UPDATE jobs SET status='pending', node_id=NULL,
         gpu_device_id=NULL, cpu_device_id=NULL,
         assigned_at=NULL, completed_at=NULL
     WHERE node_id=? AND status='processing'"
);
$stmt->bind_param('i', $node_id);
$stmt->execute();
$stmt->close();
$stmt = $db->prepare("UPDATE gpus SET status='free' WHERE node_id=?");
$stmt->bind_param('i', $node_id); $stmt->execute(); $stmt->close();
$stmt = $db->prepare("UPDATE cpus SET status='free' WHERE node_id=?");
$stmt->bind_param('i', $node_id); $stmt->execute(); $stmt->close();

/* ── 2. Register GPUs ───────────────────────────────────────────────── */
if (!empty($body['gpus'])) {
    $stmt = $db->prepare(
        "INSERT INTO gpus (node_id, device_id, model, throughput, perf_info, status, level)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         model=VALUES(model), throughput=VALUES(throughput),
         perf_info=VALUES(perf_info), status=VALUES(status), level=VALUES(level)"
    );
    foreach ($body['gpus'] as $g) {
        $did  = (int)($g['device_id']  ?? 0);
        $mdl  = (string)($g['model']     ?? '');
        $tp   = (float)($g['throughput'] ?? 0);
        $info = (string)($g['perf_info'] ?? '');
        $st   = (string)($g['status']    ?? 'free');
        $lvl  = 6; // v1.9: single-tier system — every device is level 6
        $stmt->bind_param('iisdssi', $node_id, $did, $mdl, $tp, $info, $st, $lvl);
        $stmt->execute();
    }
    $stmt->close();
}

/* ── 3. Register CPUs ───────────────────────────────────────────────── */
if (!empty($body['cpus'])) {
    $stmt = $db->prepare(
        "INSERT INTO cpus (node_id, device_id, model, throughput, perf_info, status, level)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         model=VALUES(model), throughput=VALUES(throughput),
         perf_info=VALUES(perf_info), status=VALUES(status), level=VALUES(level)"
    );
    foreach ($body['cpus'] as $c) {
        $did  = (int)($c['device_id']  ?? 0);
        $mdl  = (string)($c['model']     ?? '');
        $tp   = (float)($c['throughput'] ?? 0);
        $info = (string)($c['perf_info'] ?? '');
        $lvl  = 6; // v1.9: single-tier system — every device is level 6
        /* Check OS online status: cpu0 has no 'online' file (always on).
         * Any other core with online=0 is disabled at the hardware/kernel level. */
        $online_file = "/sys/devices/system/cpu/cpu{$did}/online";
        $cpu_online  = !file_exists($online_file) || trim(file_get_contents($online_file)) === '1';
        $st = $cpu_online ? (string)($c['status'] ?? 'free') : 'offline';
        $stmt->bind_param('iisdssi', $node_id, $did, $mdl, $tp, $info, $st, $lvl);
        $stmt->execute();
    }
    $stmt->close();
}

echo json_encode(['status' => 'ok', 'node_id' => $node_id]);
