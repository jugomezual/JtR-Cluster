<?php
/*
 * GET /api/node/job?node_ip=<ip>&id_gpu=<n>   — GPU requests a job
 * GET /api/node/job?node_ip=<ip>&id_cpu=<n>   — CPU requests a job
 *
 * v1.9: single-tier system — every job is level 6. Any device (CPU or GPU)
 * is assigned the next pending job, regardless of the device's own throughput.
 *
 * Response: job JSON  { job_id, hash, type, quantum, charset,
 *                       hash_id, node_ip, gpu_device_id|cpu_device_id }
 *        or error JSON { "error": "..." }
 */

require_once __DIR__ . '/../../includes/includes.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$node_ip = $_GET['node_ip'] ?? '';
$id_gpu  = array_key_exists('id_gpu', $_GET) ? (int)$_GET['id_gpu'] : null;
$id_cpu  = array_key_exists('id_cpu', $_GET) ? (int)$_GET['id_cpu'] : null;

$is_cpu = $id_cpu !== null;
$is_gpu = $id_gpu !== null && !$is_cpu;

if ($node_ip === '' || (!$is_cpu && !$is_gpu)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

/* ── Claim device atomically ─────────────────────────────────────────── */
$device_id = $is_gpu ? $id_gpu : $id_cpu;
$tbl       = $is_gpu ? 'gpus' : 'cpus';
$dev_col   = $is_gpu ? 'gpu_device_id' : 'cpu_device_id';
$ip_e      = $db->real_escape_string($node_ip);

/*
 * Lock the device row first (FOR UPDATE), then decide:
 *  - If busy with an active processing job → reject (device already working).
 *  - If busy but no active job (stall/crash) → clear and claim.
 *  - If free → claim immediately.
 * Marking busy inside the same transaction prevents two concurrent requests
 * from assigning two jobs to the same device.
 */
$db->begin_transaction();
$res = $db->query(
    "SELECT t.id, t.status, n.id AS node_id
     FROM $tbl t JOIN nodes n ON n.id = t.node_id
     WHERE t.device_id=$device_id AND n.ip='$ip_e'
     FOR UPDATE"
);
$row = $res ? $res->fetch_assoc() : null;
if (!$row) {
    $db->rollback();
    http_response_code(404);
    echo json_encode(['error' => 'Device not registered']);
    exit;
}

$node_db_id = (int)$row['node_id'];

if ($row['status'] === 'offline') {
    $db->rollback();
    http_response_code(403);
    echo json_encode(['error' => 'Device is offline']);
    exit;
}

/*
 * Always check for an active processing job on this device, regardless of
 * device status. This catches the case where result.php freed the device
 * (step 2) before it could update the job status (step 1), leaving a
 * 'processing' job with a 'free' device — an inconsistent state that would
 * otherwise allow a second job to be assigned to the same device.
 */
$chk = $db->query(
    "SELECT 1 FROM jobs WHERE status='processing'
     AND node_id=$node_db_id AND $dev_col=$device_id LIMIT 1"
);
if ($chk && $chk->fetch_row()) {
    $db->rollback();
    echo json_encode(['error' => 'Device already processing a job']);
    exit;
}

/* Mark device busy before we leave the transaction */
$db->query(
    "UPDATE $tbl SET status='busy'
     WHERE id={$row['id']}"
);
$db->commit();

/* ── find_and_assign: selects and assigns one pending level-6 job ────── */
function find_and_assign(mysqli $db, string $node_ip,
                         bool $is_gpu, ?int $gpu_id, ?int $cpu_id): int {
    $db->begin_transaction();

    $sel = "SELECT j.id FROM jobs j JOIN hashes h ON h.id = j.hash_id
            WHERE j.status='pending' AND j.enabled=1 AND j.level=6
            AND (h.result IS NULL OR h.result='')
            ORDER BY j.id ASC LIMIT 1 FOR UPDATE SKIP LOCKED";

    $res    = $db->query($sel);
    $row    = $res ? $res->fetch_assoc() : null;
    $job_id = $row ? (int)$row['id'] : -1;
    if ($job_id < 0) { $db->rollback(); return -1; }

    $ip_e = $db->real_escape_string($node_ip);
    if ($is_gpu) {
        $upd = "UPDATE jobs SET status='processing', assigned_at=NOW(),
                gpu_device_id=$gpu_id, cpu_device_id=NULL,
                node_id=(SELECT id FROM nodes WHERE ip='$ip_e') WHERE id=$job_id";
    } else {
        $upd = "UPDATE jobs SET status='processing', assigned_at=NOW(),
                cpu_device_id=$cpu_id, gpu_device_id=NULL,
                node_id=(SELECT id FROM nodes WHERE ip='$ip_e') WHERE id=$job_id";
    }
    if (!$db->query($upd)) { $db->rollback(); return -1; }
    $db->commit();
    return $job_id;
}

$job_id = find_and_assign($db, $node_ip, $is_gpu, $id_gpu, $id_cpu);

if ($job_id === -1) {
    /* No job found — free the device we just claimed */
    $db->query(
        "UPDATE $tbl SET status='free' WHERE id={$row['id']}"
    );
    echo json_encode(['error' => $is_gpu ? 'No pending jobs for GPU' : 'No pending jobs for CPU']);
    exit;
}

/* ── Return job details ──────────────────────────────────────────────── */
$stmt = $db->prepare(
    "SELECT j.id, h.hash_text, h.hash_type, j.quantum, c.description,
            COALESCE(j.$dev_col, -1) AS dev_id, j.hash_id, h.charset_id
     FROM jobs j
     JOIN hashes h  ON h.id  = j.hash_id
     JOIN charset c ON c.id  = h.charset_id
     WHERE j.id = ?"
);
$stmt->bind_param('i', $job_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    echo json_encode(['error' => 'Error reading job data']);
    exit;
}

$resp = [
    'job_id'  => (int)$row['id'],
    'hash'    => $row['hash_text'],
    'type'    => $row['hash_type'],
    'quantum' => $row['quantum'],
    'charset' => $row['description'],
    'hash_id' => (string)$row['hash_id'],
    'node_ip' => $node_ip,
];
if ((int)$row['charset_id'] === 3) {
    $resp['charset_3'] = '?l?u?d';
}
if ($is_gpu) $resp['gpu_device_id'] = (int)$row['dev_id'];
else         $resp['cpu_device_id'] = (int)$row['dev_id'];

echo json_encode($resp);
