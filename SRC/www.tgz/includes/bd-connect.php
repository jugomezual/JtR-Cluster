<?php
/*
 * bd-connect.php — Opens the MySQL connection using parameters from config.php.
 *
 * Exposes a single global variable: $db (mysqli instance).
 * Loaded automatically by includes.php.
 */

require_once __DIR__ . '/../config.php';

$db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->set_charset(DB_CHARSET);

if ($db->connect_error) {
    die('DB connection failed: ' . $db->connect_error);
}
