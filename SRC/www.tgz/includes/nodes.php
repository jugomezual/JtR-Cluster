<?php
/*
 * nodes.php — Data functions and HTML renderer for the `nodes` table.
 */

/* Return all nodes with device counts and live busy/online state. */
function nodes_get_all(mysqli $db): array {
    $r = $db->query("
        SELECT n.id, n.ip, n.has_gpu, n.has_cpu,
          (SELECT COUNT(*) FROM cpus WHERE node_id = n.id) AS cpu_devices,
          (SELECT COUNT(*) FROM gpus WHERE node_id = n.id) AS gpu_devices,
          (SELECT MAX(updated_at) FROM cpus WHERE node_id = n.id) AS last_cpu,
          (SELECT MAX(updated_at) FROM gpus WHERE node_id = n.id) AS last_gpu,
          (SELECT COUNT(*) FROM jobs j
           WHERE j.node_id = n.id AND j.status = 'processing'
             AND j.gpu_device_id IS NOT NULL) AS busy_gpu,
          (SELECT COUNT(*) FROM jobs j
           WHERE j.node_id = n.id AND j.status = 'processing'
             AND j.cpu_device_id IS NOT NULL) AS busy_cpu
        FROM nodes n
        ORDER BY n.id");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/* Total number of registered nodes. */
function nodes_count(mysqli $db): int {
    return (int)$db->query("SELECT COUNT(*) n FROM nodes")->fetch_assoc()['n'];
}

/* Render the full Nodes tab: nodes table + CPUs table + GPUs table. */
function render_nodes(mysqli $db): void {
    $nodes   = nodes_get_all($db);
    $cpuRows = cpus_get_all($db);
    $gpuRows = gpus_get_all($db);

    $deviceColgroup = '
        <colgroup>
            <col class="col-w-110">
            <col class="col-w-65">
            <col>
            <col class="col-w-160">
            <col class="col-w-150">
            <col class="col-w-105">
            <col class="col-w-165">
        </colgroup>';
    ?>

    <h5 class="mb-3">Registered nodes</h5>
    <div class="table-responsive mb-4">
        <table class="table table-bordered table-striped table-hover table-fixed">
            <colgroup>
                <col class="col-w-50">
                <col class="col-w-150">
                <col class="col-w-160">
                <col class="col-w-160">
                <col class="col-w-180">
                <col>
            </colgroup>
            <thead class="table-light">
                <tr>
                    <th>ID</th><th>IP</th><th>GPU</th><th>CPU</th>
                    <th>Devices</th><th>Last activity</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($nodes as $nd):
                $lastAct = max($nd['last_cpu'] ?? '', $nd['last_gpu'] ?? '');
            ?>
            <tr>
                <td><?= $nd['id'] ?></td>
                <td><?= htmlspecialchars($nd['ip']) ?></td>
                <td><?= $nd['has_gpu'] ? node_badge($nd['busy_gpu'] > 0 ? 'processing' : 'online') : '' ?></td>
                <td><?= $nd['has_cpu'] ? node_badge($nd['busy_cpu'] > 0 ? 'processing' : 'online') : '' ?></td>
                <td>
                    <span class="badge bg-light text-dark border">CPU: <?= (int)$nd['cpu_devices'] ?></span>
                    <span class="badge bg-light text-dark border">GPU: <?= (int)$nd['gpu_devices'] ?></span>
                </td>
                <td class="text-muted small"><?= $lastAct ? htmlspecialchars($lastAct) : '—' ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- CPUs -->
    <h5 class="mb-2">CPUs</h5>
    <div class="table-responsive mb-4">
        <table class="table table-bordered table-striped table-hover">
            <?= $deviceColgroup ?>
            <thead class="table-light">
                <tr>
                    <th>Node</th><th>Device</th>
                    <th>Model</th><th>Perf info</th>
                    <th>Throughput (GH/s)</th><th>Status</th><th>Last update</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($cpuRows as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['node_ip']) ?></td>
                <td><?= $row['device_id'] ?></td>
                <td class="model-col" title="<?= htmlspecialchars(trim($row['model'] ?? '')) ?>">
                    <?= htmlspecialchars(trim($row['model'] ?? '—')) ?></td>
                <td><?= fmt_perf($row['perf_info'] ?? '') ?></td>
                <td><?= number_format(($row['throughput'] ?? 0) / 1e9, 3, ',', '.') ?></td>
                <td><?= status_badge($row['status']) ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['updated_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- GPUs -->
    <h5 class="mb-2">GPUs</h5>
    <div class="table-responsive mb-4">
        <table class="table table-bordered table-striped table-hover">
            <?= $deviceColgroup ?>
            <thead class="table-light">
                <tr>
                    <th>Node</th><th>Device</th>
                    <th>Model</th><th>Perf info</th>
                    <th>Throughput (GH/s)</th><th>Status</th><th>Last update</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($gpuRows as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['node_ip']) ?></td>
                <td><?= $row['device_id'] ?></td>
                <td class="model-col" title="<?= htmlspecialchars(trim($row['model'] ?? '')) ?>">
                    <?= htmlspecialchars(trim($row['model'] ?? '—')) ?></td>
                <td><?= fmt_perf($row['perf_info'] ?? '') ?></td>
                <td><?= number_format(($row['throughput'] ?? 0) / 1e9, 3, ',', '.') ?></td>
                <td><?= status_badge($row['status']) ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['updated_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
