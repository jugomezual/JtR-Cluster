<?php
/*
 * hashes.php — Data functions and HTML renderers for the `hashes` table.
 */

/*
 * Look up a hash by its text value.
 * Returns ['id' => int, 'result' => string|null] or null if not found.
 */
function hashes_find_by_text(mysqli $db, string $hashText): ?array {
    $stmt = $db->prepare("SELECT id, result FROM hashes WHERE hash_text = ?");
    $stmt->bind_param('s', $hashText);
    $stmt->execute();
    $stmt->bind_result($id, $result);
    $found = $stmt->fetch();
    $stmt->close();
    return $found ? ['id' => $id, 'result' => $result] : null;
}

/*
 * Insert a new hash/file record.
 * Returns the auto-incremented id, or throws RuntimeException on failure.
 */
function hashes_insert(
    mysqli  $db,
    string  $hashType,
    int     $charsetId,
    string  $email,
    int     $passwordLength,
    ?string $hashText,
    ?string $uploadedFile,
    ?string $comment = null
): int {
    $comment = ($comment !== null && $comment !== '') ? substr($comment, 0, 255) : null;
    if ($hashText === null || $hashText === '') {
        $stmt = $db->prepare(
            "INSERT INTO hashes (hash_text, hash_type, charset_id, email, comment, password_length, uploaded_file, result)
             VALUES (NULL, ?, ?, ?, ?, ?, ?, NULL)"
        );
        $stmt->bind_param('sissis', $hashType, $charsetId, $email, $comment, $passwordLength, $uploadedFile);
    } else {
        $stmt = $db->prepare(
            "INSERT INTO hashes (hash_text, hash_type, charset_id, email, comment, password_length, uploaded_file, result)
             VALUES (?, ?, ?, ?, ?, ?, ?, NULL)"
        );
        $stmt->bind_param('ssissis', $hashText, $hashType, $charsetId, $email, $comment, $passwordLength, $uploadedFile);
    }

    if (!$stmt->execute()) {
        $err = $db->error;
        $stmt->close();
        throw new RuntimeException("Error saving hash: $err");
    }
    $id = $db->insert_id;
    $stmt->close();
    return $id;
}

/*
 * Send a cracked-password result to an email address.
 * Uses the system mail command (same as the C server).
 */
/* Notify user that their hash was cracked (password found). */
function hashes_notify_cracked(string $email, string $hashText, string $password): void {
    $subject = 'Hash cracked: password found';
    $body    = "Your hash has been successfully cracked.\n\n"
             . "Hash:     $hashText\n"
             . "Password: $password\n\n"
             . "Regards,\nDistributed Cracking System";
    mail($email, $subject, $body);
}

/* Notify user that all combinations were exhausted without finding the password. */
function hashes_notify_not_found(string $email, string $hashText): void {
    $subject = 'Hash: password not found';
    $body    = "Unfortunately, your hash could not be cracked after "
             . "exhausting all combinations.\n\n"
             . "Hash: $hashText\n\n"
             . "Regards,\nDistributed Cracking System";
    mail($email, $subject, $body);
}

/*
 * Counts of submitted and cracked hashes/files.
 * Returns:
 *   total_hashes   — single-hash submissions
 *   total_files    — file submissions
 *   cracked_hashes — cracked single-hash submissions
 *   cracked_files  — cracked file submissions
 */
function hashes_count(mysqli $db): array {
    $cracked = "result IS NOT NULL AND result NOT IN ('NOT_FOUND','')";
    return [
        'total_hashes'   => (int)$db->query("SELECT COUNT(*) n FROM hashes WHERE uploaded_file IS NULL")->fetch_assoc()['n'],
        'total_files'    => (int)$db->query("SELECT COUNT(*) n FROM hashes WHERE uploaded_file IS NOT NULL")->fetch_assoc()['n'],
        'cracked_hashes' => (int)$db->query("SELECT COUNT(*) n FROM hashes WHERE $cracked AND uploaded_file IS NULL")->fetch_assoc()['n'],
        'cracked_files'  => (int)$db->query("SELECT COUNT(*) n FROM hashes WHERE $cracked AND uploaded_file IS NOT NULL")->fetch_assoc()['n'],
    ];
}

/*
 * All cracked single-hash submissions (result IS NOT NULL, not a file).
 * Returns full rows including timing and job counts.
 */
function hashes_get_cracked(mysqli $db): array {
    $r = $db->query("
        SELECT h.id, h.hash_type, h.hash_text, h.result, h.email, h.comment,
               h.password_length, h.created_at,
               (SELECT j.assigned_at FROM jobs j
                WHERE j.hash_id = h.id AND j.status = 'found'
                LIMIT 1) AS found_at,
               TIMESTAMPDIFF(SECOND, h.created_at,
                   (SELECT j.assigned_at FROM jobs j
                    WHERE j.hash_id = h.id AND j.status = 'found'
                    LIMIT 1)) AS seconds_taken,
               (SELECT COUNT(*) FROM jobs j
                WHERE j.hash_id = h.id
                  AND j.cpu_device_id IS NOT NULL
                  AND j.status IN ('found','not_found')) AS cpu_jobs,
               (SELECT COUNT(*) FROM jobs j
                WHERE j.hash_id = h.id
                  AND j.gpu_device_id IS NOT NULL
                  AND j.status IN ('found','not_found')) AS gpu_jobs
        FROM hashes h
        WHERE h.result IS NOT NULL
          AND h.result NOT IN ('NOT_FOUND','')
          AND h.uploaded_file IS NULL
        ORDER BY h.id DESC");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/*
 * All exhausted (not-found) single-hash submissions.
 */
function hashes_get_not_found(mysqli $db): array {
    $r = $db->query("
        SELECT h.id, h.hash_type, h.hash_text, h.email, h.comment,
               h.password_length, h.created_at,
               (SELECT MAX(j.assigned_at) FROM jobs j
                WHERE j.hash_id = h.id
                  AND j.status IN ('found','not_found')) AS last_job_at,
               TIMESTAMPDIFF(SECOND, h.created_at,
                   (SELECT MAX(j.assigned_at) FROM jobs j
                    WHERE j.hash_id = h.id
                      AND j.status IN ('found','not_found'))) AS seconds_taken,
               (SELECT COUNT(*) FROM jobs j
                WHERE j.hash_id = h.id
                  AND j.cpu_device_id IS NOT NULL
                  AND j.status IN ('found','not_found')) AS cpu_jobs,
               (SELECT COUNT(*) FROM jobs j
                WHERE j.hash_id = h.id
                  AND j.gpu_device_id IS NOT NULL
                  AND j.status IN ('found','not_found')) AS gpu_jobs
        FROM hashes h
        WHERE (h.result IS NULL OR h.result IN ('NOT_FOUND',''))
          AND h.uploaded_file IS NULL
          AND EXISTS (SELECT 1 FROM jobs j
                      WHERE j.hash_id = h.id AND j.status = 'not_found')
        ORDER BY h.id DESC");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/*
 * All cracked file submissions.
 */
function hashes_get_cracked_files(mysqli $db): array {
    $r = $db->query("
        SELECT h.id, h.hash_type, h.uploaded_file, h.result, h.email, h.comment,
               h.password_length, h.charset_id, h.created_at
        FROM hashes h
        WHERE h.result IS NOT NULL
          AND h.result NOT IN ('NOT_FOUND','')
          AND h.uploaded_file IS NOT NULL
        ORDER BY h.id DESC");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/* Render the Hashes cracked tab: cracked table + not-found table. */
function render_hashes_cracked(mysqli $db): void {
    $hashRows    = hashes_get_cracked($db);
    $notFoundRows = hashes_get_not_found($db);
    ?>

    <!-- ── Cracked ── -->
    <div class="d-flex align-items-center gap-3 mb-3">
        <h5 class="mb-0">Cracked hashes</h5>
        <span class="badge bg-success"><?= count($hashRows) ?> cracked</span>
    </div>

    <?php if (empty($hashRows)): ?>
    <div class="alert alert-secondary">No cracked hashes yet.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th class="col-icon"></th>
                    <th>ID</th><th>Type</th><th>Hash</th>
                    <th>Password</th><th>Max length</th>
                    <th>Processing time</th><th>CPU jobs</th><th>GPU jobs</th>
                    <th>Comment</th><th>Email</th><th>Submitted</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($hashRows as $row): ?>
            <tr>
                <td class="text-center">
                    <a href="hash_report.php?id=<?= $row['id'] ?>" title="View report"
                       class="text-secondary icon-link-sm" target="_blank">
                        <i class="bi bi-bar-chart-line-fill"></i>
                    </a>
                </td>
                <td><?= $row['id'] ?></td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['hash_type']) ?></span></td>
                <td><code class="hash-truncate" title="<?= htmlspecialchars($row['hash_text']) ?>">
                    <?= htmlspecialchars($row['hash_text']) ?></code></td>
                <td><strong class="text-success"><?= htmlspecialchars(trim($row['result'])) ?></strong></td>
                <td><?= (int)$row['password_length'] ?></td>
                <td class="text-muted small"><?= fmt_duration($row['seconds_taken'] !== null ? (int)$row['seconds_taken'] : null) ?></td>
                <td><?= (int)$row['cpu_jobs'] ?></td>
                <td><?= (int)$row['gpu_jobs'] ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['comment'] ?? '') ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['created_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <!-- ── Not found ── -->
    <div class="d-flex align-items-center gap-3 mb-3 mt-4">
        <h5 class="mb-0">Not found hashes</h5>
        <span class="badge bg-secondary"><?= count($notFoundRows) ?> not found</span>
    </div>

    <?php if (empty($notFoundRows)): ?>
    <div class="alert alert-secondary">No exhausted hashes yet.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th class="col-icon"></th>
                    <th>ID</th><th>Type</th><th>Hash</th>
                    <th>Max length</th>
                    <th>Processing time</th><th>CPU jobs</th><th>GPU jobs</th>
                    <th>Comment</th><th>Email</th><th>Submitted</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($notFoundRows as $row): ?>
            <tr>
                <td class="text-center">
                    <a href="hash_report.php?id=<?= $row['id'] ?>" title="View report"
                       class="text-secondary icon-link-sm" target="_blank">
                        <i class="bi bi-bar-chart-line"></i>
                    </a>
                </td>
                <td><?= $row['id'] ?></td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['hash_type']) ?></span></td>
                <td><code class="hash-truncate" title="<?= htmlspecialchars($row['hash_text']) ?>">
                    <?= htmlspecialchars($row['hash_text']) ?></code></td>
                <td><?= (int)$row['password_length'] ?></td>
                <td class="text-muted small"><?= fmt_duration($row['seconds_taken'] !== null ? (int)$row['seconds_taken'] : null) ?></td>
                <td><?= (int)$row['cpu_jobs'] ?></td>
                <td><?= (int)$row['gpu_jobs'] ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['comment'] ?? '') ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['created_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif;
}

/* Render the Files cracked tab. */
function render_files_cracked(mysqli $db): void {
    $fileRows = hashes_get_cracked_files($db);
    ?>

    <div class="d-flex align-items-center gap-3 mb-3">
        <h5 class="mb-0">Cracked files</h5>
        <span class="badge bg-success"><?= count($fileRows) ?> cracked</span>
    </div>

    <?php if (empty($fileRows)): ?>
    <div class="alert alert-secondary">No cracked files yet.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th>ID</th><th>Type</th><th>File</th>
                    <th>Password</th><th>Max length</th><th>Comment</th><th>Email</th><th>Submitted</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($fileRows as $row): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['hash_type']) ?></span></td>
                <td><?= htmlspecialchars($row['uploaded_file'] ?? '—') ?></td>
                <td><strong class="text-success"><?= htmlspecialchars(trim($row['result'])) ?></strong></td>
                <td><?= (int)$row['password_length'] ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['comment'] ?? '') ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td class="text-muted small"><?= htmlspecialchars($row['created_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif;
}
