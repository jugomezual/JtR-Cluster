<?php
/*
 * helpers.php — Pure formatting/display helper functions (no DB access).
 */

/* Format a throughput value (H/s) as MH/s with 2 decimal places. */
function fmt_mhs(float $v): string {
    return number_format($v / 1e6, 2, ',', '');
}

/* Format a perf_info value: numeric → "X.X MHz", empty/unknown → em dash. */
function fmt_perf(string $v): string {
    $v = trim($v);
    if ($v === '' || strtolower($v) === 'unknown info') {
        return '<span class="text-muted">—</span>';
    }
    return is_numeric($v)
        ? htmlspecialchars(number_format((float)$v, 1, ',', '.')) . ' <small class="text-muted">MHz</small>'
        : htmlspecialchars($v);
}

/* Render a Bootstrap badge for a device/job status value. */
function status_badge(string $status): string {
    return match ($status) {
        'busy'       => '<span class="badge bg-primary">● Busy</span>',
        'free'       => '<span class="badge bg-success">● Free</span>',
        'error'      => '<span class="badge bg-danger">● Error</span>',
        'processing' => '<span class="badge bg-light text-muted border">⏳ Processing</span>',
        'pending'    => '<span class="badge bg-secondary">⏸ Pending</span>',
        'found'      => '<span class="badge bg-success">✔ Found</span>',
        'not_found'  => '<span class="badge bg-secondary">✘ Not found</span>',
        'discarded'  => '<span class="badge bg-warning text-dark">⊘ Discarded</span>',
        default      => '<span class="badge bg-light text-dark">' . htmlspecialchars($status) . '</span>',
    };
}

/* Render a large Bootstrap badge for a node's overall state. */
function node_badge(string $s): string {
    return match ($s) {
        'processing' => '<span class="badge bg-primary fs-6 px-3 py-2">● Processing</span>',
        'online'     => '<span class="badge bg-success fs-6 px-3 py-2">● Online</span>',
        default      => '<span class="badge bg-danger  fs-6 px-3 py-2">● Offline</span>',
    };
}

/* Format a duration in seconds as "1h 23m 45s". */
function fmt_duration(?int $secs): string {
    if ($secs === null || $secs < 0) return '—';
    if ($secs < 60)   return $secs . 's';
    if ($secs < 3600) return floor($secs / 60) . 'm ' . ($secs % 60) . 's';
    return floor($secs / 3600) . 'h ' . floor(($secs % 3600) / 60) . 'm ' . ($secs % 60) . 's';
}
