<?php
/*
 * includes.php — Master include file.
 *
 * A single require of this file is enough for any page that needs
 * database access or the shared library functions:
 *
 *   require_once __DIR__ . '/includes/includes.php';   // from www/
 *   require_once __DIR__ . '/../includes/includes.php'; // from www/admin/
 */

require_once __DIR__ . '/bd-connect.php';   // $db — mysqli connection
require_once __DIR__ . '/helpers.php';      // fmt_mhs, fmt_perf, status_badge, node_badge, fmt_duration
require_once __DIR__ . '/cpus.php';         // cpus table
require_once __DIR__ . '/gpus.php';         // gpus table
require_once __DIR__ . '/nodes.php';        // nodes table + render_nodes()
require_once __DIR__ . '/jobs.php';         // jobs table + render_processing()
require_once __DIR__ . '/hashes.php';       // hashes table + render_hashes_cracked() + render_files_cracked()
require_once __DIR__ . '/dashboard.php';    // cross-table stats + render_dashboard()
