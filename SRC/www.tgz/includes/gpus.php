<?php
/*
 * gpus.php — Data functions for the `gpus` table.
 */

/* Return all GPU rows joined with their node IP, plus computed live status. */
function gpus_get_all(mysqli $db): array {
    $r = $db->query("
        SELECT g.id, n.ip AS node_ip, g.device_id,
               g.model, g.perf_info, g.throughput, g.level, g.updated_at,
               IF(EXISTS(
                   SELECT 1 FROM jobs j
                   WHERE j.node_id = g.node_id
                     AND j.gpu_device_id = g.device_id
                     AND j.status = 'processing'
               ), 'busy', 'free') AS status
        FROM gpus g
        JOIN nodes n ON n.id = g.node_id
        ORDER BY g.node_id, g.device_id");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/* Sum of throughput across all GPUs (H/s). */
function gpus_total_throughput(mysqli $db): float {
    return (float)$db->query(
        "SELECT COALESCE(SUM(throughput), 0) v FROM gpus"
    )->fetch_assoc()['v'];
}

/* Sum of throughput across GPUs currently marked busy (H/s). */
function gpus_busy_throughput(mysqli $db): float {
    return (float)$db->query(
        "SELECT COALESCE(SUM(throughput), 0) v FROM gpus WHERE status = 'busy'"
    )->fetch_assoc()['v'];
}
