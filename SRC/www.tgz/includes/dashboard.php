<?php
/*
 * dashboard.php — Aggregate stats and HTML renderer for the Dashboard tab.
 * Queries span multiple tables (cpus, gpus, nodes, jobs, hashes).
 */

/*
 * Collect all KPI values needed for the dashboard.
 * Returns an associative array with keys:
 *   total_cpu, total_gpu, total_global,
 *   busy_cpu,  busy_gpu,  busy_global,
 *   pct_cpu,   pct_gpu,   pct_global,
 *   cnt_nodes,
 *   cnt_processing, cnt_pending,
 *   cnt_total_hashes, cnt_total_files, cnt_total,
 *   cnt_cracked_hashes, cnt_cracked_files, cnt_cracked
 */
function dashboard_get_stats(mysqli $db): array {
    $totalCpu    = cpus_total_throughput($db);
    $totalGpu    = gpus_total_throughput($db);
    $totalGlobal = $totalCpu + $totalGpu;

    $busyCpu     = cpus_busy_throughput($db);
    $busyGpu     = gpus_busy_throughput($db);
    $busyGlobal  = $busyCpu + $busyGpu;

    $counts = hashes_count($db);

    return [
        'total_cpu'    => $totalCpu,
        'total_gpu'    => $totalGpu,
        'total_global' => $totalGlobal,
        'busy_cpu'     => $busyCpu,
        'busy_gpu'     => $busyGpu,
        'busy_global'  => $busyGlobal,
        'pct_cpu'      => $totalCpu    > 0 ? round($busyCpu    * 100 / $totalCpu)    : 0,
        'pct_gpu'      => $totalGpu    > 0 ? round($busyGpu    * 100 / $totalGpu)    : 0,
        'pct_global'   => $totalGlobal > 0 ? round($busyGlobal * 100 / $totalGlobal) : 0,
        'cnt_nodes'          => nodes_count($db),
        'cnt_processing'     => jobs_count_processing($db),
        'cnt_pending'        => jobs_count_pending($db),
        'cnt_total_hashes'   => $counts['total_hashes'],
        'cnt_total_files'    => $counts['total_files'],
        'cnt_total'          => $counts['total_hashes'] + $counts['total_files'],
        'cnt_cracked_hashes' => $counts['cracked_hashes'],
        'cnt_cracked_files'  => $counts['cracked_files'],
        'cnt_cracked'        => $counts['cracked_hashes'] + $counts['cracked_files'],
    ];
}

/* Render the Dashboard tab: throughput KPI cards + stats row. */
function render_dashboard(mysqli $db): void {
    $s = dashboard_get_stats($db);

    $kpis = [
        ['label' => 'CPU throughput',    'total' => $s['total_cpu'],    'busy' => $s['busy_cpu'],    'pct' => $s['pct_cpu'],    'bg' => 'text-bg-primary'],
        ['label' => 'GPU throughput',    'total' => $s['total_gpu'],    'busy' => $s['busy_gpu'],    'pct' => $s['pct_gpu'],    'bg' => 'text-bg-success'],
        ['label' => 'Global throughput', 'total' => $s['total_global'], 'busy' => $s['busy_global'], 'pct' => $s['pct_global'], 'bg' => 'text-bg-dark'],
    ];
    ?>

    <!-- ── Performance ── -->
    <h5 class="mb-3">Performance</h5>
    <div class="row mb-4">
        <?php foreach ($kpis as $k): ?>
        <div class="col-md-4 mb-3">
            <div class="card kpi-card <?= $k['bg'] ?>">
                <div class="card-body">
                    <h6 class="card-title text-uppercase opacity-75 mb-1 kpi-title">
                        <?= $k['label'] ?>
                    </h6>
                    <p class="card-text fs-3 mb-2 fw-semibold">
                        <?= fmt_mhs($k['total']) ?> <span class="fs-6 opacity-75">MH/s</span>
                    </p>
                    <div class="progress mb-1">
                        <div class="progress-bar bg-danger pct-bar" role="progressbar"
                             style="--pct:<?= $k['pct'] ?>%">
                            <?= $k['pct'] ?>% &nbsp;(<?= fmt_mhs($k['busy']) ?> MH/s busy)
                        </div>
                    </div>
                    <div class="d-flex justify-content-between progress-labels">
                        <span>0%</span><span>100%</span>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ── Active host/devices ── -->
    <?php
    $gpus = gpus_get_all($db);
    $cpus = cpus_get_all($db);

    /* Group by level */
    $gpu_by_level = []; foreach ($gpus as $d) $gpu_by_level[(int)$d['level']][] = $d;
    $cpu_by_level = []; foreach ($cpus as $d) $cpu_by_level[(int)$d['level']][] = $d;
    ?>
    <h5 class="mt-4 mb-3">Active host/devices</h5>
    <div class="row g-3 mb-2">

        <!-- Registered nodes -->
        <div class="col-6 col-md-4">
            <div class="card stat-card blue h-100">
                <div class="card-body py-3">
                    <div class="fs-2 fw-bold text-primary"><?= $s['cnt_nodes'] ?></div>
                    <div class="text-muted small">Registered nodes</div>
                </div>
            </div>
        </div>

        <!-- CPUs by level -->
        <div class="col-6 col-md-4">
            <div class="card stat-card h-100">
                <div class="card-body py-3">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="bi bi-cpu-fill text-info"></i>
                        <span class="fw-semibold">CPUs</span>
                        <span class="badge bg-secondary ms-auto"><?= count($cpus) ?> total</span>
                    </div>
                    <?php if (empty($cpus)): ?>
                        <div class="text-muted small">No CPUs registered</div>
                    <?php else: foreach ([7,6,5] as $lv):
                        if (empty($cpu_by_level[$lv])) continue;
                        $lbadge = $lv === 7 ? 'danger' : ($lv === 6 ? 'warning' : 'info');
                        $n      = count($cpu_by_level[$lv]);
                    ?>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="badge bg-<?= $lbadge ?>">L<?= $lv ?></span>
                            <span class="fs-5 fw-bold"><?= $n ?></span>
                            <small class="text-muted"><?= $n === 1 ? 'core' : 'cores' ?></small>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>

        <!-- GPUs by level -->
        <div class="col-6 col-md-4">
            <div class="card stat-card h-100">
                <div class="card-body py-3">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="bi bi-gpu-card text-warning"></i>
                        <span class="fw-semibold">GPUs</span>
                        <span class="badge bg-secondary ms-auto"><?= count($gpus) ?> total</span>
                    </div>
                    <?php if (empty($gpus)): ?>
                        <div class="text-muted small">No GPUs registered</div>
                    <?php else: foreach ([7,6,5] as $lv):
                        if (empty($gpu_by_level[$lv])) continue;
                        $lbadge = $lv === 7 ? 'danger' : ($lv === 6 ? 'warning' : 'info');
                        $n      = count($gpu_by_level[$lv]);
                    ?>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="badge bg-<?= $lbadge ?>">L<?= $lv ?></span>
                            <span class="fs-5 fw-bold"><?= $n ?></span>
                            <small class="text-muted"><?= $n === 1 ? 'device' : 'devices' ?></small>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>

    </div>

    <!-- ── Hashes ── -->
    <h5 class="mt-4 mb-3">Hashes</h5>
    <div class="row g-3 mb-2">
        <div class="col-6 col-md-4">
            <div class="card stat-card orange h-100">
                <div class="card-body py-3">
                    <div class="fs-2 fw-bold text-warning"><?= $s['cnt_processing'] + $s['cnt_pending'] ?></div>
                    <div class="text-muted small">Jobs in queue
                        <span class="ms-1 badge bg-warning text-dark"><?= $s['cnt_processing'] ?> active</span>
                        <span class="badge bg-secondary"><?= $s['cnt_pending'] ?> pending</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4">
            <div class="card stat-card purple h-100">
                <div class="card-body py-3">
                    <div class="fs-2 fw-bold text-purple"><?= $s['cnt_total'] ?></div>
                    <div class="text-muted small">Total hashes submitted
                        <span class="d-block mt-1">
                            <span class="badge bg-secondary"><?= $s['cnt_total_hashes'] ?> hashes</span>
                            <span class="badge bg-secondary"><?= $s['cnt_total_files'] ?> files</span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4">
            <div class="card stat-card green h-100">
                <div class="card-body py-3">
                    <div class="fs-2 fw-bold text-success"><?= $s['cnt_cracked'] ?></div>
                    <div class="text-muted small">Passwords cracked
                        <span class="d-block mt-1">
                            <span class="badge bg-success"><?= $s['cnt_cracked_hashes'] ?> hashes</span>
                            <span class="badge bg-success"><?= $s['cnt_cracked_files'] ?> files</span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}
