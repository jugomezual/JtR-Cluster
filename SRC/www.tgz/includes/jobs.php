<?php
/*
 * jobs.php — Data functions and HTML renderer for the `jobs` table.
 */

/* ── Charset definitions (must stay in sync with generador_quantums.c) ───── */
define('CHARSET_JOHN', [
    '?d',
    '?l',
    '?u',
    '?3',
    '?a',
]);
define('CHARSET_REAL', [
    '0123456789',
    'abcdefghijklmnopqrstuvwxyz',
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    " !\"#\$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",
]);

/*
 * Recursively collect all prefix-expanded quantum strings into $out.
 * Each '?' literal in a prefix char is escaped as '??' per JtR mask syntax.
 */
function _jobs_collect_prefixes(
    string $chars, string $joker,
    string $prefix, int $wildcards, int $excess,
    int $level, array &$out
): void {
    if ($excess === 0) {
        $out[] = [$prefix . str_repeat($joker, $wildcards), $level];
        return;
    }
    $n = strlen($chars);
    for ($i = 0; $i < $n; $i++) {
        $c = $chars[$i];
        _jobs_collect_prefixes(
            $chars, $joker,
            $prefix . ($c === '?' ? '??' : $c),
            $wildcards, $excess - 1, $level, $out
        );
    }
}

/*
 * Generate and insert all quantum jobs for a hash.
 *
 * Replicates the logic of bin/generador_quantums.c in pure PHP so the
 * form submission (procesar.php) can call it directly via $db without
 * shelling out to the compiled binary.
 *
 * Returns the number of jobs inserted.
 * Throws RuntimeException if the hash_id is not found.
 */
function jobs_generate_quantums(mysqli $db, int $hash_id): int {
    $stmt = $db->prepare("SELECT password_length, charset_id FROM hashes WHERE id = ?");
    $stmt->bind_param('i', $hash_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) throw new RuntimeException("Hash ID $hash_id not found.");

    $password_length = (int)$row['password_length'];
    $charset_id      = (int)$row['charset_id'];
    $joker           = CHARSET_JOHN[$charset_id];
    $chars           = CHARSET_REAL[$charset_id];

    // v1.9: single-tier system — every job is level 6, fixed depth of 6 chars
    $level     = 6;
    $max_level = 6;

    // Collect all [quantum, level] pairs first, then insert in one transaction
    $quanta = [];
    for ($len = 1; $len <= $password_length; $len++) {
        if ($len <= $max_level) {
            $quanta[] = [str_repeat($joker, $len), $level];
        } else {
            // Pre-expand the excess length into prefix-fixed jobs at fixed depth 6
            _jobs_collect_prefixes($chars, $joker, '', $max_level, $len - $max_level, $level, $quanta);
        }
    }

    $stmt = $db->prepare(
        "INSERT INTO jobs (hash_id, quantum, enabled, status, level) VALUES (?, ?, 1, 'pending', ?)"
    );
    $db->begin_transaction();
    foreach ($quanta as [$quantum, $level]) {
        $stmt->bind_param('isi', $hash_id, $quantum, $level);
        $stmt->execute();
    }
    $db->commit();
    $stmt->close();

    return count($quanta);
}

/* Total jobs currently in 'processing' or 'pending' state. */
function jobs_count_active_total(mysqli $db): int {
    return (int)$db->query(
        "SELECT COUNT(*) n FROM jobs WHERE status IN ('processing','pending')"
    )->fetch_assoc()['n'];
}

/* Jobs currently being actively processed. */
function jobs_count_processing(mysqli $db): int {
    return (int)$db->query(
        "SELECT COUNT(*) n FROM jobs WHERE status = 'processing'"
    )->fetch_assoc()['n'];
}

/* Jobs waiting to be picked up. */
function jobs_count_pending(mysqli $db): int {
    return (int)$db->query(
        "SELECT COUNT(*) n FROM jobs WHERE status = 'pending'"
    )->fetch_assoc()['n'];
}

/* Total number of registered devices (CPUs + GPUs). */
function devices_count(mysqli $db): int {
    $r = $db->query("SELECT (SELECT COUNT(*) FROM cpus) + (SELECT COUNT(*) FROM gpus) AS n");
    return (int)($r->fetch_assoc()['n'] ?? 0);
}

/*
 * Active/pending job rows for the processing table, limited to $limit rows.
 * Returns: id, hash_id, hash_type, hash_label, quantum, status,
 *          device, node_ip, assigned_at.
 */
function jobs_get_active(mysqli $db, int $limit = 50): array {
    $limit = max(1, $limit);
    $r = $db->query("
        SELECT j.id, h.id AS hash_id, h.hash_type,
               LEFT(COALESCE(h.hash_text, h.uploaded_file, '?'), 40) AS hash_label,
               j.quantum, j.status,
               CASE WHEN j.gpu_device_id IS NOT NULL THEN CONCAT('GPU-', j.gpu_device_id)
                    WHEN j.cpu_device_id IS NOT NULL THEN CONCAT('CPU-', j.cpu_device_id)
                    ELSE '—' END AS device,
               n.ip AS node_ip, j.assigned_at
        FROM jobs j
        JOIN hashes h ON h.id = j.hash_id
        LEFT JOIN nodes n ON n.id = j.node_id
        WHERE j.status IN ('processing','pending')
        ORDER BY j.status DESC, j.assigned_at DESC
        LIMIT $limit");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/*
 * Per-hash summary of in-progress work (for hashes not yet cracked).
 * Returns: id, hash_type, label, pending, processing, not_found, total.
 */
function jobs_get_summary(mysqli $db): array {
    $r = $db->query("
        SELECT h.id, h.hash_type,
               LEFT(COALESCE(h.hash_text, h.uploaded_file, '?'), 40) AS label,
               SUM(j.status = 'pending')    AS pending,
               SUM(j.status = 'processing') AS processing,
               SUM(j.status = 'not_found')  AS not_found,
               COUNT(j.id)                  AS total,
               SUM(CASE WHEN j.status NOT IN ('splited','joined')
                        THEN j.jobs_count * POW(
                            CASE h.charset_id WHEN 0 THEN 10 WHEN 1 THEN 26
                                              WHEN 2 THEN 26 WHEN 3 THEN 62
                                              ELSE 95 END,
                            j.level)
                        ELSE 0 END)         AS combos_total,
               SUM(CASE WHEN j.node_id IS NOT NULL AND j.status IN ('found','not_found')
                        THEN j.jobs_count * POW(
                            CASE h.charset_id WHEN 0 THEN 10 WHEN 1 THEN 26
                                              WHEN 2 THEN 26 WHEN 3 THEN 62
                                              ELSE 95 END,
                            j.level)
                        ELSE 0 END)         AS combos_done
        FROM hashes h
        JOIN jobs j ON j.hash_id = h.id
        WHERE h.result IS NULL
        GROUP BY h.id
        HAVING pending > 0 OR processing > 0
        ORDER BY h.id DESC");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/* Render the Processing tab: summary table + active/pending jobs table. */
function render_processing(mysqli $db): void {
    $totalProc   = jobs_count_active_total($db);
    $devCount    = max(50, devices_count($db));
    $procRows    = jobs_get_active($db, $devCount);
    $summaryRows = jobs_get_summary($db);

    /* ── Hashes currently in progress ── */
    if (!empty($summaryRows)): ?>
    <h5 class="mb-3">Hashes currently in progress</h5>
    <div class="table-responsive mb-4">
        <table class="table table-bordered table-hover">
            <thead class="table-light">
                <tr>
                    <th>Hash ID</th><th>Type</th><th>Hash / File</th>
                    <th>Total quantums</th><th>Processing</th><th>Pending</th><th>Not found</th>
                    <th>Progress</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($summaryRows as $row):
                $combos_total = (float)$row['combos_total'];
                $combos_done  = (float)$row['combos_done'];
                $pct = $combos_total > 0 ? round($combos_done * 100 / $combos_total) : 0;
            ?>
            <tr>
                <td class="d-flex align-items-center gap-2 border-0">
                    <?= $row['id'] ?>
                    <a href="hash_report.php?id=<?= $row['id'] ?>" target="_blank"
                       title="View report" class="text-secondary icon-link-sm">
                        <i class="bi bi-bar-chart-line-fill"></i>
                    </a>
                </td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['hash_type']) ?></span></td>
                <td><code><?= htmlspecialchars($row['label']) ?></code></td>
                <td><?= $row['total'] ?></td>
                <td><?= $row['processing'] ?></td>
                <td><?= $row['pending'] ?></td>
                <td><?= $row['not_found'] ?></td>
                <td class="td-progress">
                    <div class="progress progress-sm">
                        <div class="progress-bar bg-primary pct-bar" style="--pct:<?= $pct ?>%">
                            <?= $pct ?>%
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif;

    if (empty($procRows)): ?>
    <div class="alert alert-secondary mt-2">
        <strong>No active jobs.</strong> The system is idle — all pending quantums have been processed.
    </div>
    <?php else: ?>

    <!-- ── Active & pending jobs ── -->
    <h5 class="mb-3">Active &amp; pending jobs
        <span class="badge bg-secondary ms-1"><?= $totalProc ?></span>
        <?php if ($totalProc > $devCount): ?>
        <small class="text-muted ms-2 fw-normal text-hint-sm">showing first <?= $devCount ?></small>
        <?php endif; ?>
    </h5>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover table-fixed">
            <colgroup>
                <col class="col-w-60">
                <col class="col-w-65">
                <col class="col-w-65">
                <col class="col-w-160">
                <col class="col-w-180">
                <col class="col-w-110">
                <col class="col-w-115">
                <col class="col-w-80">
                <col class="col-w-140">
            </colgroup>
            <thead class="table-light">
                <tr>
                    <th>Job ID</th><th>Hash ID</th><th>Type</th>
                    <th>Hash / File</th><th>Quantum</th>
                    <th>Status</th><th>Node IP</th><th>Device</th><th>Assigned at</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($procRows as $row): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['hash_id'] ?></td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['hash_type']) ?></span></td>
                <td class="td-truncate">
                    <code title="<?= htmlspecialchars($row['hash_label']) ?>">
                    <?= htmlspecialchars($row['hash_label']) ?></code></td>
                <td class="td-truncate">
                    <code class="text-truncate" title="<?= htmlspecialchars($row['quantum']) ?>"><?= htmlspecialchars($row['quantum']) ?></code>
                </td>
                <td><?= status_badge($row['status']) ?></td>
                <td><?= htmlspecialchars($row['node_ip'] ?? '—') ?></td>
                <td><code><?= htmlspecialchars($row['device']) ?></code></td>
                <td class="text-muted small"><?= htmlspecialchars($row['assigned_at'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif;
}
