<?php
/*
 * cpus.php — Data functions for the `cpus` table.
 */

/* Return all CPU rows joined with their node IP, plus computed live status. */
function cpus_get_all(mysqli $db): array {
    $r = $db->query("
        SELECT c.id, n.ip AS node_ip, c.device_id,
               c.model, c.perf_info, c.throughput, c.level, c.updated_at,
               IF(EXISTS(
                   SELECT 1 FROM jobs j
                   WHERE j.node_id = c.node_id
                     AND j.cpu_device_id = c.device_id
                     AND j.status = 'processing'
               ), 'busy', 'free') AS status
        FROM cpus c
        JOIN nodes n ON n.id = c.node_id
        ORDER BY c.node_id, c.device_id");
    return $r->fetch_all(MYSQLI_ASSOC);
}

/* Sum of throughput across all CPUs (H/s). */
function cpus_total_throughput(mysqli $db): float {
    return (float)$db->query(
        "SELECT COALESCE(SUM(throughput), 0) v FROM cpus"
    )->fetch_assoc()['v'];
}

/* Sum of throughput across CPUs currently marked busy (H/s). */
function cpus_busy_throughput(mysqli $db): float {
    return (float)$db->query(
        "SELECT COALESCE(SUM(throughput), 0) v FROM cpus WHERE status = 'busy'"
    )->fetch_assoc()['v'];
}
