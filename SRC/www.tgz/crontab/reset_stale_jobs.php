<?php
/*
 * crontab/reset_stale_jobs.php
 *
 * Resets stalled processing jobs back to 'pending' so they can be
 * reassigned.  Jobs are considered stalled when they have been in
 * 'processing' state longer than the stall timeout and the hash has
 * not yet been cracked.
 *
 * v1.9: single-tier system — every job is level 6, stall timeout by device
 * type (not by hash — no per-hash exemptions, removed 2026-09-19): CPU jobs
 * get 10h, GPU jobs get 2h.
 *
 * Run every 10 minutes via crontab:
 */
// */10 * * * * php /jtr-cluster/www/crontab/reset_stale_jobs.php

require_once __DIR__ . '/../includes/includes.php';

$cpu_timeout_hours = 11;
$gpu_timeout_hours = 2;

/* Reset stalled jobs whose hash is not yet cracked */
$db->query(
    "UPDATE jobs j JOIN hashes h ON h.id = j.hash_id
     SET j.status='pending', j.node_id=NULL,
         j.gpu_device_id=NULL, j.cpu_device_id=NULL,
         j.assigned_at=NULL, j.completed_at=NULL
     WHERE j.status='processing' AND j.level=6
     AND j.assigned_at < CASE WHEN j.cpu_device_id IS NOT NULL
                               THEN (NOW() - INTERVAL $cpu_timeout_hours HOUR)
                               ELSE (NOW() - INTERVAL $gpu_timeout_hours HOUR) END
     AND (h.result IS NULL OR h.result = '')"
);

/* Discard stalled jobs whose hash is already cracked */
$db->query(
    "UPDATE jobs j JOIN hashes h ON h.id = j.hash_id
     SET j.status='discarded', j.completed_at=NOW()
     WHERE j.status='processing' AND j.level=6
     AND j.assigned_at < CASE WHEN j.cpu_device_id IS NOT NULL
                               THEN (NOW() - INTERVAL $cpu_timeout_hours HOUR)
                               ELSE (NOW() - INTERVAL $gpu_timeout_hours HOUR) END
     AND h.result IS NOT NULL AND h.result != ''"
);
