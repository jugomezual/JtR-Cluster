/*
 * worker.h — GPU and CPU worker thread structs and cracking loops.
 *
 * Each thread runs an infinite loop:
 *   1. Request a job quantum from the server.
 *   2. Run John the Ripper with the assigned hash and mask.
 *   3. Report the result (found/not-found + password) back to the server.
 *
 * Thread entry points:
 *   worker_loop_gpu(void *WorkerArgsGpu *)
 *   worker_loop_cpu(void *WorkerArgsCpu *)
 */
#ifndef WORKER_H
#define WORKER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <limits.h>
#ifndef PATH_MAX
#define PATH_MAX 4096
#endif
#include <pthread.h>
#include <json-c/json.h>

#include "config.h"
#include "network.h"
#include "logger.h"

#define HASH_DIR  "./hashes"
#define LINEBUF   32768

/* ── Thread argument structs ── */

typedef struct {
    int    id_cpu;
    char   node_ip[64];
    Config cfg;          /* copy of runtime config (server addr, john path) */
} WorkerArgsCpu;

typedef struct {
    int    id_gpu;
    char   node_ip[64];
    char   platform[128]; /* OCL short platform name, e.g. "NVIDIA" or "rusticl" */
    Config cfg;
} WorkerArgsGpu;

/* ── Internal helpers ── */

/*
 * Build a shell-safe single-quoted string for the JtR --mask argument.
 * Single quotes protect all shell metacharacters except ' itself.
 * Any ' in the mask is replaced with the sequence '\''.
 * dst must be large enough: worst case 4*srclen + 3 bytes.
 */
static void _shell_single_quote(char *dst, size_t dstlen, const char *src) {
    size_t pos = 0;
    dst[pos++] = '\'';
    for (; *src && pos + 5 < dstlen; src++) {
        if (*src == '\'') {
            dst[pos++] = '\''; dst[pos++] = '\\';
            dst[pos++] = '\''; dst[pos++] = '\'';
        } else {
            dst[pos++] = *src;
        }
    }
    dst[pos++] = '\'';
    dst[pos]   = '\0';
}

/*
 * Escape characters that are special in JtR's own --mask syntax (see
 * doc/MASK): an unescaped '[' opens a character-range group (corrupting
 * the rest of the mask if never closed), and '\' is the escape character
 * itself. The server sends quanta with prefixes drawn from the full
 * printable-ASCII charset, which includes both, and only escapes a
 * literal '?' (by doubling it to "??") before sending — '[' and '\' pass
 * through unescaped. Fix them here, once, right before building the JtR
 * command line, so it covers every quantum regardless of how it was
 * generated. Literal '\' must become "\\" and literal '[' must become
 * "\[". dst must be large enough: worst case 2*srclen + 1 bytes.
 */
static void _jtr_mask_escape(char *dst, size_t dstlen, const char *src) {
    size_t pos = 0;
    for (; *src && pos + 3 < dstlen; src++) {
        if (*src == '\\' || *src == '[') dst[pos++] = '\\';
        dst[pos++] = *src;
    }
    dst[pos] = '\0';
}

/* Strip ANSI escape sequences (e.g. \033[0m) from a string in-place. */
static void _strip_ansi(char *s) {
    char *src = s, *dst = s;
    while (*src) {
        if (*src == '\033' && *(src + 1) == '[') {
            src += 2;
            while (*src && *src != 'm' && *src != 'K' && *src != 'J') src++;
            if (*src) src++;
        } else {
            *dst++ = *src++;
        }
    }
    *dst = '\0';
}

/* Write hash text to a file (creates/overwrites). */
static void _save_hash_file(const char *filename, const char *hash) {
    FILE *f = fopen(filename, "w");
    if (f) {
        fprintf(f, "%s\n", hash);
        fclose(f);
    } else {
        log_error("Cannot create hash file: %s", filename);
    }
}

/* Search potfile for hash; if found, copy the cracked password into password[passlen].
 * Returns 1 if found, 0 otherwise. */
static int _extract_password_from_potfile(const char *potfile, const char *hash,
                                           char *password, size_t passlen) {
    FILE *f = fopen(potfile, "r");
    if (!f) return 0;
    char line[LINEBUF];
    int found = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, hash)) {
            char *last_colon = strrchr(line, ':');
            if (last_colon && *(last_colon + 1)) {
                char *nl = strchr(last_colon, '\n');
                if (nl) *nl = '\0';
                strncpy(password, last_colon + 1, passlen - 1);
                password[passlen - 1] = '\0';
                found = 1;
                break;
            }
        }
    }
    fclose(f);
    return found;
}

/* Map hash type string to the JtR OpenCL format name. */
static const char *_type_to_format_gpu(const char *type) {
    if (strcasecmp(type, "SHA1")   == 0) return "raw-sha1-opencl";
    if (strcasecmp(type, "SHA256") == 0) return "raw-sha256-opencl";
    if (strcasecmp(type, "SHA512") == 0) return "raw-sha512-opencl";
    if (strcasecmp(type, "MD5")    == 0) return "raw-md5-opencl";
    if (strcasecmp(type, "BCRYPT") == 0) return "bcrypt-opencl";
    if (strcasecmp(type, "pdf")    == 0) return "pdf-opencl";
    if (strcasecmp(type, "office") == 0) return "office-opencl";
    if (strcasecmp(type, "zip")    == 0) return "ZIP-opencl";
    if (strcasecmp(type, "rar")    == 0) return "RAR5-opencl";
    if (strcasecmp(type, "7z")     == 0) return "7z-opencl";
    return "raw-md5-opencl";
}

/* Map hash type string to the JtR CPU format name. */
static const char *_type_to_format_cpu(const char *type) {
    if (strcasecmp(type, "SHA1")   == 0) return "raw-sha1";
    if (strcasecmp(type, "SHA256") == 0) return "raw-sha256";
    if (strcasecmp(type, "SHA512") == 0) return "raw-sha512";
    if (strcasecmp(type, "MD5")    == 0) return "raw-md5";
    if (strcasecmp(type, "BCRYPT") == 0) return "bcrypt";
    if (strcasecmp(type, "pdf")    == 0) return "pdf";
    if (strcasecmp(type, "office") == 0) return "office";
    if (strcasecmp(type, "zip")    == 0) return "PKZIP";
    if (strcasecmp(type, "rar")    == 0) return "RAR5";
    if (strcasecmp(type, "7z")     == 0) return "7z";
    return "raw-md5";
}

/* ── GPU worker thread ── */

void *worker_loop_gpu(void *arg) {
    WorkerArgsGpu *w = (WorkerArgsGpu *)arg;
    int  id_gpu = w->id_gpu;
    char node_ip[64];
    char platform[128];
    Config cfg;
    strncpy(node_ip,  w->node_ip,  sizeof(node_ip)  - 1);
    strncpy(platform, w->platform, sizeof(platform) - 1);
    cfg = w->cfg;

    log_info("[GPU %d] Worker started (platform: %s)", id_gpu,
             platform[0] ? platform : "auto");

    char job_url[512], result_url[512];
    snprintf(job_url,    sizeof(job_url),    "%s/job",    cfg.api_url);
    snprintf(result_url, sizeof(result_url), "%s/result", cfg.api_url);

    while (1) {
        /* ── 1. Request a job quantum ── */
        char req_url[640];
        snprintf(req_url, sizeof(req_url), "%s?node_ip=%s&id_gpu=%d",
                 job_url, node_ip, id_gpu);

        char response[NET_BUFFER] = "";
        http_get(req_url, response, sizeof(response));

        if (strstr(response, "error")) {
            if (strstr(response, "No pending jobs")) {
                log_info("[GPU %d] No pending jobs. Waiting 20 s ...", id_gpu);
                sleep(20);
            }
            /* else: race condition — another worker grabbed it, retry immediately */
            continue;
        }

        json_object *q = json_tokener_parse(response);
        if (!q) {
            log_error("[GPU %d] Cannot parse server response: %s", id_gpu, response);
            sleep(20);
            continue;
        }

        int         job_id    = json_object_get_int   (json_object_object_get(q, "job_id"));
        const char *hash      = json_object_get_string(json_object_object_get(q, "hash"));
        const char *type      = json_object_get_string(json_object_object_get(q, "type"));
        const char *quantum   = json_object_get_string(json_object_object_get(q, "quantum"));
        const char *hash_id   = json_object_get_string(json_object_object_get(q, "hash_id"));
        json_object *cs3_obj  = json_object_object_get(q, "charset_3");
        const char *charset_3 = cs3_obj ? json_object_get_string(cs3_obj) : NULL;

        /* ── 2. Prepare hash file ── */
        mkdir(HASH_DIR, 0755);
        char hashfile[PATH_MAX], hashfile_abs[PATH_MAX];
        snprintf(hashfile, sizeof(hashfile), "%s/%s.txt", HASH_DIR, hash_id);
        if (access(hashfile, F_OK) != 0)
            _save_hash_file(hashfile, hash);
        if (!realpath(hashfile, hashfile_abs))
            strncpy(hashfile_abs, hashfile, sizeof(hashfile_abs) - 1);

        /* ── 3. Build and run JtR command ── */
        const char *format = _type_to_format_gpu(type);
        char potfile[128], session[160], recfile[176], cmd[4096];
        char jtr_mask[1024], safe_mask[1024], charset_arg[64];
        snprintf(potfile,  sizeof(potfile),  "potfile_gpu%d.txt",    id_gpu);
        snprintf(session,  sizeof(session),  "session_gpu%d_%d",     id_gpu, job_id);
        snprintf(recfile,  sizeof(recfile),  "%s.rec",               session);
        _jtr_mask_escape(jtr_mask, sizeof(jtr_mask), quantum);
        _shell_single_quote(safe_mask, sizeof(safe_mask), jtr_mask);
        if (charset_3 && charset_3[0])
            snprintf(charset_arg, sizeof(charset_arg), " -3='%s'", charset_3);
        else
            charset_arg[0] = '\0';
        unlink(recfile);  /* remove any stale checkpoint from a previous killed run */

        /* JtR uses 1-based device numbering; our id_gpu is 0-based */
        int jtr_device = id_gpu + 1;
        if (platform[0])
            snprintf(cmd, sizeof(cmd),
                "OCL_ICD_DEFAULT_PLATFORM=%s"
                " %s --format=%s %s --mask=%s%s --devices=%d --pot=%s --session=%s"
                " --no-log --verbosity=4 2>&1",
                platform, cfg.john_path, format,
                hashfile_abs, safe_mask, charset_arg, jtr_device, potfile, session);
        else
            snprintf(cmd, sizeof(cmd),
                "%s --format=%s %s --mask=%s%s --devices=%d"
                " --pot=%s --session=%s --no-log --verbosity=4 2>&1",
                cfg.john_path, format,
                hashfile_abs, safe_mask, charset_arg, jtr_device, potfile, session);

        log_info("[GPU %d] Running: %s", id_gpu, cmd);
        char password[256] = "";
        int  found = 0;
        FILE *fp = popen(cmd, "r");
        if (fp) {
            char line[2048], prevline[2048] = "";
            while (fgets(line, sizeof(line), fp)) {
                log_info("[GPU %d] %s", id_gpu, line);

                /* JtR prints "1g" on DONE when a password was cracked */
                if (strstr(line, "1g") && strstr(line, "DONE")) {
                    char *paren = strchr(prevline, '(');
                    int passlen = paren ? (int)(paren - prevline) : (int)strlen(prevline);
                    while (passlen > 0 &&
                           (prevline[passlen-1] == ' ' || prevline[passlen-1] == '\t'))
                        passlen--;
                    if (passlen > 0 && passlen < (int)sizeof(password)) {
                        strncpy(password, prevline, passlen);
                        password[passlen] = '\0';
                        found = 1;
                    }
                }
                if (strstr(line, "0g") && strstr(line, "DONE")) {
                    found = 0;
                    password[0] = '\0';
                }
                strncpy(prevline, line, sizeof(prevline) - 1);
                prevline[sizeof(prevline) - 1] = '\0';
            }
            pclose(fp);
        }
        unlink(recfile);  /* remove session checkpoint — avoids resume on next job */

        /* ── 4. Extract result ── */
        /* Strip ANSI color codes JtR may include in its terminal output */
        if (found) _strip_ansi(password);

        /* Fallback: scan potfile for hash types where potfile extraction is reliable */
        if (!found)
            found = _extract_password_from_potfile(potfile, hash, password, sizeof(password));
        unlink(potfile);

        /* ── 5. Report result ── */
        json_object *jout = json_object_new_object();
        json_object_object_add(jout, "job_id",   json_object_new_int(job_id));
        json_object_object_add(jout, "found",    json_object_new_boolean(found));
        json_object_object_add(jout, "password", json_object_new_string(password));
        json_object_object_add(jout, "node_ip",  json_object_new_string(node_ip));
        json_object_object_add(jout, "id_gpu",   json_object_new_int(id_gpu));
        json_object_object_add(jout, "hash_id",  json_object_new_string(hash_id));

        const char *result_json = json_object_to_json_string(jout);
        char resp2[NET_BUFFER];
        while (1) {
            resp2[0] = '\0';
            int rc = http_post(result_url, result_json, resp2, sizeof(resp2));
            if (rc == 0) break;
            log_info("[GPU %d] Result send failed, retrying in 5 s ...", id_gpu);
            sleep(5);
        }
        log_info("[GPU %d] Result reported (found=%d): %s", id_gpu, found, password);
        json_object_put(jout);
        json_object_put(q);

        // sleep(2);  // disabled for performance test — see project_jtrcluster_rendimiento memory
    }

    free(w);
    pthread_exit(NULL);
}

/* ── CPU worker thread ── */

void *worker_loop_cpu(void *arg) {
    WorkerArgsCpu *w = (WorkerArgsCpu *)arg;
    int  id_cpu = w->id_cpu;
    char node_ip[64];
    Config cfg;
    strncpy(node_ip, w->node_ip, sizeof(node_ip) - 1);
    cfg = w->cfg;

    log_info("[CPU %d] Worker started", id_cpu);

    char job_url[512], result_url[512];
    snprintf(job_url,    sizeof(job_url),    "%s/job",    cfg.api_url);
    snprintf(result_url, sizeof(result_url), "%s/result", cfg.api_url);

    while (1) {
        /* ── 1. Request a job quantum ── */
        char req_url[640];
        snprintf(req_url, sizeof(req_url), "%s?node_ip=%s&id_cpu=%d",
                 job_url, node_ip, id_cpu);

        char response[NET_BUFFER] = "";
        http_get(req_url, response, sizeof(response));

        if (strstr(response, "error")) {
            if (strstr(response, "No pending jobs")) {
                log_info("[CPU %d] No pending jobs. Waiting 20 s ...", id_cpu);
                sleep(20);
            }
            /* else: race condition — another worker grabbed it, retry immediately */
            continue;
        }

        json_object *q = json_tokener_parse(response);
        if (!q) {
            log_error("[CPU %d] Cannot parse server response: %s", id_cpu, response);
            sleep(20);
            continue;
        }

        int         job_id    = json_object_get_int   (json_object_object_get(q, "job_id"));
        const char *hash      = json_object_get_string(json_object_object_get(q, "hash"));
        const char *type      = json_object_get_string(json_object_object_get(q, "type"));
        const char *quantum   = json_object_get_string(json_object_object_get(q, "quantum"));
        const char *hash_id   = json_object_get_string(json_object_object_get(q, "hash_id"));
        json_object *cs3_obj  = json_object_object_get(q, "charset_3");
        const char *charset_3 = cs3_obj ? json_object_get_string(cs3_obj) : NULL;

        /* ── 2. Prepare hash file ── */
        mkdir(HASH_DIR, 0755);
        char hashfile[PATH_MAX], hashfile_abs[PATH_MAX];
        snprintf(hashfile, sizeof(hashfile), "%s/%s.txt", HASH_DIR, hash_id);
        if (access(hashfile, F_OK) != 0)
            _save_hash_file(hashfile, hash);
        if (!realpath(hashfile, hashfile_abs))
            strncpy(hashfile_abs, hashfile, sizeof(hashfile_abs) - 1);

        /* ── 3. Build and run JtR command ── */
        const char *format = _type_to_format_cpu(type);
        char potfile[128], session[160], recfile[176], cmd[4096];
        char jtr_mask[1024], safe_mask[1024], charset_arg[64];
        snprintf(potfile,  sizeof(potfile),  "potfile_cpu%d.txt",    id_cpu);
        snprintf(session,  sizeof(session),  "session_cpu%d_%d",     id_cpu, job_id);
        snprintf(recfile,  sizeof(recfile),  "%s.rec",               session);
        _jtr_mask_escape(jtr_mask, sizeof(jtr_mask), quantum);
        _shell_single_quote(safe_mask, sizeof(safe_mask), jtr_mask);
        if (charset_3 && charset_3[0])
            snprintf(charset_arg, sizeof(charset_arg), " -3='%s'", charset_3);
        else
            charset_arg[0] = '\0';
        unlink(recfile);  /* remove any stale checkpoint from a previous killed run */
        snprintf(cmd, sizeof(cmd),
            "OMP_NUM_THREADS=1 taskset -c %d %s --format=%s %s --mask=%s%s"
            " --pot=%s --session=%s --no-log --verbosity=4 2>&1",
            id_cpu, cfg.john_path, format,
            hashfile_abs, safe_mask, charset_arg, potfile, session);

        log_info("[CPU %d] Running: %s", id_cpu, cmd);
        char password[256] = "";
        int  found = 0;
        FILE *fp = popen(cmd, "r");
        if (fp) {
            char line[2048], prevline[2048] = "";
            while (fgets(line, sizeof(line), fp)) {
                log_info("[CPU %d] %s", id_cpu, line);

                /* JtR prints "1g" on DONE when a password was cracked */
                if (strstr(line, "1g") && strstr(line, "DONE")) {
                    char *paren = strchr(prevline, '(');
                    int passlen = paren ? (int)(paren - prevline) : (int)strlen(prevline);
                    while (passlen > 0 &&
                           (prevline[passlen-1] == ' ' || prevline[passlen-1] == '\t'))
                        passlen--;
                    if (passlen > 0 && passlen < (int)sizeof(password)) {
                        strncpy(password, prevline, passlen);
                        password[passlen] = '\0';
                        found = 1;
                    }
                }
                if (strstr(line, "0g") && strstr(line, "DONE")) {
                    found = 0;
                    password[0] = '\0';
                }
                strncpy(prevline, line, sizeof(prevline) - 1);
                prevline[sizeof(prevline) - 1] = '\0';
            }
            pclose(fp);
        }

        unlink(recfile);  /* remove session checkpoint — avoids resume on next job */

        /* Strip ANSI color codes JtR may include in its terminal output */
        if (found) _strip_ansi(password);

        /* Fallback: scan potfile in case JtR output was ambiguous */
        if (!found)
            found = _extract_password_from_potfile(potfile, hash, password, sizeof(password));
        unlink(potfile);

        /* ── 4. Report result ── */
        json_object *jout = json_object_new_object();
        json_object_object_add(jout, "job_id",   json_object_new_int(job_id));
        json_object_object_add(jout, "found",    json_object_new_boolean(found));
        json_object_object_add(jout, "password", json_object_new_string(password));
        json_object_object_add(jout, "node_ip",  json_object_new_string(node_ip));
        json_object_object_add(jout, "id_cpu",   json_object_new_int(id_cpu));
        json_object_object_add(jout, "hash_id",  json_object_new_string(hash_id));

        const char *result_json = json_object_to_json_string(jout);
        char resp2[NET_BUFFER];
        while (1) {
            resp2[0] = '\0';
            int rc = http_post(result_url, result_json, resp2, sizeof(resp2));
            if (rc == 0) break;
            log_info("[CPU %d] Result send failed, retrying in 5 s ...", id_cpu);
            sleep(5);
        }
        log_info("[CPU %d] Result reported (found=%d): %s", id_cpu, found, password);
        json_object_put(jout);
        json_object_put(q);

        // sleep(2);  // disabled for performance test — see project_jtrcluster_rendimiento memory
    }

    free(w);
    pthread_exit(NULL);
}

#endif /* WORKER_H */
