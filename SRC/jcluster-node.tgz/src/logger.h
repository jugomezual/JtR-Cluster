/*
 * logger.h — Thread-safe timestamped logging to stdout and a log file.
 *
 * Usage:
 *   log_open(LOG_PATH);      // call once at startup
 *   log_info("started");
 *   log_warn("low memory");
 *   log_error("connection failed: %s", err);
 *   log_close();             // call at shutdown
 */
#ifndef LOGGER_H
#define LOGGER_H

#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <pthread.h>

#ifndef LOG_PATH
#define LOG_PATH "./logs.txt"
#endif

typedef enum { LOG_INFO = 0, LOG_WARN = 1, LOG_ERROR = 2 } LogLevel;

static FILE            *_log_fp  = NULL;
static pthread_mutex_t  _log_mtx = PTHREAD_MUTEX_INITIALIZER;

static const char *_log_labels[] = { "INFO ", "WARN ", "ERROR" };

/* Open (append) the log file. Call once before any log_* macro. */
static void log_open(const char *path) {
    _log_fp = fopen(path ? path : LOG_PATH, "a");
    if (!_log_fp)
        fprintf(stderr, "[LOGGER] Cannot open log file: %s\n", path ? path : LOG_PATH);
}

/* Flush and close the log file. */
static void log_close(void) {
    if (_log_fp) { fclose(_log_fp); _log_fp = NULL; }
}

/* Internal: write one log line with timestamp and level label. */
static void _log_write(LogLevel lvl, const char *fmt, ...) {
    char ts[32], msg[2048];

    time_t now = time(NULL);
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", localtime(&now));

    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    pthread_mutex_lock(&_log_mtx);

    if (_log_fp) {
        fprintf(_log_fp, "[%s] [%s] %s\n", ts, _log_labels[lvl], msg);
        fflush(_log_fp);
    } else {
        printf("[%s] [%s] %s\n", ts, _log_labels[lvl], msg);
        fflush(stdout);
    }

    pthread_mutex_unlock(&_log_mtx);
}

/* Public macros — use these instead of calling _log_write directly. */
#define log_info(...)  _log_write(LOG_INFO,  __VA_ARGS__)
#define log_warn(...)  _log_write(LOG_WARN,  __VA_ARGS__)
#define log_error(...) _log_write(LOG_ERROR, __VA_ARGS__)

#endif /* LOGGER_H */
