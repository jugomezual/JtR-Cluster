/*
 * config.h — Runtime configuration loaded from config.txt.
 *
 * Expected file format (KEY=VALUE, one per line, # for comments):
 *
 *   API_URL=http://10.0.1.4/jtrcluster/api/node
 *   JOHN_PATH=/jtr-cluster/john/run/john
 *
 * If config.txt is missing, built-in defaults are used.
 */
#ifndef CONFIG_H
#define CONFIG_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CONFIG_FILE "config.txt"

typedef struct {
    char api_url[256];    /* e.g. http://10.0.1.4/jtrcluster/api/node */
    char john_path[256];
} Config;

static void config_defaults(Config *c) {
    strncpy(c->api_url,   "http://10.0.1.4/jtrcluster/api/node", sizeof(c->api_url)   - 1);
    strncpy(c->john_path, "/jtr-cluster/john/run/john",          sizeof(c->john_path) - 1);
}

static int config_load(Config *c, const char *path) {
    config_defaults(c);

    FILE *f = fopen(path ? path : CONFIG_FILE, "r");
    if (!f) return 0;

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = '\0';
        char *key = line;
        char *val = eq + 1;
        val[strcspn(val, "\r\n")] = '\0';

        if      (strcmp(key, "API_URL")   == 0) strncpy(c->api_url,   val, sizeof(c->api_url)   - 1);
        else if (strcmp(key, "JOHN_PATH") == 0) strncpy(c->john_path, val, sizeof(c->john_path) - 1);
    }
    fclose(f);
    return 1;
}

#endif /* CONFIG_H */
