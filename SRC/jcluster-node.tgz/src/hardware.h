/*
 * hardware.h — CPU and GPU hardware detection, benchmarking, and node registration.
 *
 * Merges the logic that was previously split across cpu_report.c and gpu_report.c.
 * All john_path references come from the caller's Config struct — nothing is hardcoded.
 * GPU benchmarks are run directly with popen; no intermediate files are written.
 *
 * Public API:
 *   hw_detect_cpus()                                   — number of logical CPU cores
 *   hw_detect_gpus(cfg, ids, max, platform, plen)      — benchmark GPUs; fill IDs + platform
 *   hw_register_node(cfg, node_ip)                     — send CPU + GPU JSON to server
 */
#ifndef HARDWARE_H
#define HARDWARE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <json-c/json.h>

#include "config.h"
#include "network.h"
#include "logger.h"

/* ════════════════════════════════════════════
 *  Internal helpers (prefix _hw_)
 * ════════════════════════════════════════════ */

/* Strip leading and trailing whitespace / newlines in-place. */
static void _hw_trim(char *str) {
    /* trailing */
    char *end = str + strlen(str) - 1;
    while (end > str && (*end == '\n' || *end == '\r' || *end == ' ' || *end == '\t'))
        *end-- = '\0';
    /* leading */
    char *p = str;
    while (*p == ' ' || *p == '\t') p++;
    if (p != str) memmove(str, p, strlen(p) + 1);
}

/* Shorten an OpenCL platform name to its first word.
 * "NVIDIA CUDA" → "NVIDIA",  "Intel OpenCL HD" → "Intel" */
static void _hw_short_platform(const char *name, char *out, size_t outlen) {
    strncpy(out, name, outlen - 1);
    out[outlen - 1] = '\0';
    char *sp = strchr(out, ' ');
    if (sp) *sp = '\0';
}

/* Run a single GPU benchmark via popen (no intermediate files).
 * Returns throughput in H/s, or -1.0 on failure. */
static double _hw_benchmark_one_gpu(const char *john_path,
                                     const char *platform, int gpu_id) {
    char cmd[1024];
    if (platform && platform[0])
        snprintf(cmd, sizeof(cmd),
            "OCL_ICD_DEFAULT_PLATFORM=%s"
            " %s --test=3 --format=raw-md5-opencl --devices=%d 2>&1",
            platform, john_path, gpu_id);
    else
        snprintf(cmd, sizeof(cmd),
            "%s --test=3 --format=raw-md5-opencl --devices=%d 2>&1",
            john_path, gpu_id);

    FILE *fp = popen(cmd, "r");
    if (!fp) return -1.0;

    char line[256];
    double value = -1.0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "Raw:")) {
            char suffix = ' ';
            sscanf(line, "%*[^:]: %lf%c", &value, &suffix);
            if      (suffix == 'K') value *= 1e3;
            else if (suffix == 'M') value *= 1e6;
            else if (suffix == 'G') value *= 1e9;
            break;
        }
    }
    pclose(fp);
    return value;
}

/* ════════════════════════════════════════════
 *  CPU detection
 * ════════════════════════════════════════════ */

/*
 * Parse /sys/devices/system/cpu/online (e.g. "0-17,19-53,55-71") and fill
 * ids[] with the online CPU numbers.  Returns the count (≤ max).
 * Falls back to 0..nproc-1 if the sysfs file cannot be read.
 */
static int hw_get_online_cpus(int *ids, int max) {
    int count = 0;
    FILE *fp = fopen("/sys/devices/system/cpu/online", "r");
    if (fp) {
        char buf[1024];
        if (fgets(buf, sizeof(buf), fp)) {
            char *tok = buf;
            while (*tok && count < max) {
                int a, b;
                if (sscanf(tok, "%d-%d", &a, &b) == 2) {
                    for (int i = a; i <= b && count < max; i++)
                        ids[count++] = i;
                } else if (sscanf(tok, "%d", &a) == 1) {
                    ids[count++] = a;
                }
                tok = strchr(tok, ',');
                if (!tok) break;
                tok++;
            }
        }
        fclose(fp);
        if (count > 0) return count;
    }
    /* fallback: assume 0..nproc-1 */
    FILE *np = popen("nproc", "r");
    if (np) {
        int n = 0;
        fscanf(np, "%d", &n);
        pclose(np);
        for (int i = 0; i < n && i < max; i++) ids[i] = i;
        count = n;
    }
    return count;
}

/* Return the number of online CPU cores (convenience wrapper). */
static int hw_detect_cpus(void) {
    int ids[1024];
    return hw_get_online_cpus(ids, 1024);
}

/* Benchmark one CPU core (0-indexed) with JtR raw-md5.
 * Returns throughput in H/s, or -1 on failure. */
static long hw_cpu_throughput(int cpu_id, const char *john_path) {
    char cmd[512];
    snprintf(cmd, sizeof(cmd),
        "taskset -c %d %s --test=3 --format=raw-md5 2>&1", cpu_id, john_path);
    FILE *fp = popen(cmd, "r");
    if (!fp) return -1;

    char line[512];
    double hashes = -1.0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "c/s real")) {
            double value;
            char unit[8] = "";
            if (sscanf(line, "%*[^:]: %lf%1s", &value, unit) >= 1) {
                if      (strcmp(unit, "K") == 0) value *= 1e3;
                else if (strcmp(unit, "M") == 0) value *= 1e6;
                else if (strcmp(unit, "G") == 0) value *= 1e9;
                hashes = value;
                break;
            }
        }
    }
    pclose(fp);
    return (long)hashes;
}

/* Fill buf with the CPU model name string (trimmed). */
static void hw_cpu_model(char *buf, size_t size) {
    FILE *fp = popen("lscpu | grep 'Model name' | head -n 1 | cut -d':' -f2", "r");
    if (fp && fgets(buf, size, fp)) {
        buf[strcspn(buf, "\n")] = '\0';
        _hw_trim(buf);
    } else {
        strncpy(buf, "Unknown CPU", size - 1);
        buf[size - 1] = '\0';
    }
    if (fp) pclose(fp);
}

/* Fill buf with the CPU clock speed in MHz (trimmed numeric string).
 * Tries lscpu first; falls back to /proc/cpuinfo if lscpu gives nothing. */
static void hw_cpu_mhz(char *buf, size_t size) {
    buf[0] = '\0';

    /* 1. lscpu "CPU MHz:" */
    FILE *fp = popen("lscpu | grep 'CPU MHz' | head -n 1 | cut -d':' -f2", "r");
    if (fp) {
        if (fgets(buf, size, fp)) {
            buf[strcspn(buf, "\n")] = '\0';
            _hw_trim(buf);
        }
        pclose(fp);
    }
    if (buf[0] != '\0') return;

    /* 2. /proc/cpuinfo "cpu MHz" */
    fp = popen("grep 'cpu MHz' /proc/cpuinfo | head -n 1 | cut -d':' -f2", "r");
    if (fp) {
        if (fgets(buf, size, fp)) {
            buf[strcspn(buf, "\n")] = '\0';
            _hw_trim(buf);
        }
        pclose(fp);
    }
    if (buf[0] != '\0') return;

    strncpy(buf, "unknown info", size - 1);
    buf[size - 1] = '\0';
}

/* Build a JSON registration object for all online CPU cores.
 * Returns a new json_object — caller must call json_object_put() on it. */
static json_object *hw_build_cpu_json(const Config *cfg, const char *node_ip) {
    int cpu_ids[1024];
    int num_cpus = hw_get_online_cpus(cpu_ids, 1024);

    char model[256], mhz[128];
    hw_cpu_model(model, sizeof(model));
    hw_cpu_mhz(mhz, sizeof(mhz));

    json_object *root = json_object_new_object();
    json_object_object_add(root, "action", json_object_new_string("register"));
    json_object_object_add(root, "ip",     json_object_new_string(node_ip));

    json_object *arr = json_object_new_array();
    for (int i = 0; i < num_cpus; i++) {
        int cpu_id = cpu_ids[i];
        log_info("Benchmarking CPU core %d ...", cpu_id);
        long tp = hw_cpu_throughput(cpu_id, cfg->john_path);
        json_object *cpu = json_object_new_object();
        json_object_object_add(cpu, "device_id",  json_object_new_int(cpu_id));
        json_object_object_add(cpu, "model",      json_object_new_string(model));
        json_object_object_add(cpu, "perf_info",  json_object_new_string(mhz));
        json_object_object_add(cpu, "throughput", json_object_new_double((double)tp));
        json_object_object_add(cpu, "status",     json_object_new_string("free"));
        json_object_array_add(arr, cpu);
    }
    json_object_object_add(root, "cpus", arr);
    return root;
}

/* ════════════════════════════════════════════
 *  GPU detection
 * ════════════════════════════════════════════ */

/*
 * Enumerate OpenCL devices and fill platform_out with the short name of the
 * first GPU platform.  Returns the number of devices found, or 0.
 *
 * Internal helper — does NOT run benchmarks.
 */
static int _hw_list_gpu_devices(const char *john_path,
                                 char *platform_out, size_t plen) {
    char list_cmd[512];
    snprintf(list_cmd, sizeof(list_cmd), "%s --list=opencl-devices", john_path);
    FILE *fp = popen(list_cmd, "r");
    if (!fp) return 0;

    char line[512], current_platform[128] = "", first_gpu_platform[128] = "";
    int  count = 0;

    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "Platform #") && strstr(line, "name:")) {
            char *ptr = strstr(line, "name:");
            if (ptr) {
                strncpy(current_platform, ptr + 6, sizeof(current_platform) - 1);
                _hw_trim(current_platform);
            }
            continue;
        }
        if (strstr(line, "Device #")) {
            count++;
            if (first_gpu_platform[0] == '\0')
                strncpy(first_gpu_platform, current_platform,
                        sizeof(first_gpu_platform) - 1);
        }
    }
    pclose(fp);

    if (count > 0)
        _hw_short_platform(first_gpu_platform, platform_out, plen);
    return count;
}

/*
 * Detect GPU devices: enumerate via opencl-devices, then benchmark each one.
 *
 * Fills gpu_ids[0..n-1] with JtR 1-indexed device IDs (up to max_gpus).
 * Fills platform_out with the short platform name (e.g. "NVIDIA").
 * Returns the number of devices found.
 *
 * No intermediate files are used — benchmarks run sequentially via popen.
 */
static int hw_detect_gpus(const Config *cfg,
                           int *gpu_ids, int max_gpus,
                           char *platform_out, size_t plen) {
    char platform[128] = "";
    int  count = _hw_list_gpu_devices(cfg->john_path, platform, sizeof(platform));
    if (count == 0) return 0;

    strncpy(platform_out, platform, plen - 1);
    platform_out[plen - 1] = '\0';

    /* Fill sequential 0-based IDs (our numbering; JtR uses id+1 internally) */
    int n = count < max_gpus ? count : max_gpus;
    for (int i = 0; i < n; i++)
        gpu_ids[i] = i;
    return n;
}

/* Build a JSON registration object for all GPU devices.
 * Benchmarks each device in-process via popen (no intermediate files).
 * Returns a new json_object, or NULL if no GPUs are found.
 * Caller must call json_object_put() on the returned object. */
static json_object *hw_build_gpu_json(const Config *cfg, const char *node_ip) {
    char platform[128] = "";
    int  count = _hw_list_gpu_devices(cfg->john_path, platform, sizeof(platform));
    if (count == 0) return NULL;

    char list_cmd[512];
    snprintf(list_cmd, sizeof(list_cmd), "%s --list=opencl-devices", cfg->john_path);
    FILE *fp = popen(list_cmd, "r");
    if (!fp) return NULL;

    json_object *root  = json_object_new_object();
    json_object *array = json_object_new_array();
    json_object_object_add(root, "action",   json_object_new_string("register"));
    json_object_object_add(root, "ip",       json_object_new_string(node_ip));
    json_object_object_add(root, "platform", json_object_new_string(platform));

    char line[512], model[256] = "", extra_info[256] = "";
    int  gpu_count = 0;

    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "Device #")) {
            json_object *gpu = json_object_new_object();
            int gpu_id = gpu_count; /* default: sequential 0-based */
            int parsed = 0;
            sscanf(line, "    Device #%*d (%d)", &parsed);
            if (parsed > 0) gpu_id = parsed - 1; /* JtR reports 1-based, convert to 0-based */

            char *ptr = strstr(line, "name:");
            if (ptr) {
                strncpy(model, ptr + 6, sizeof(model) - 1);
                _hw_trim(model);
            }
            json_object_object_add(gpu, "device_id", json_object_new_int(gpu_id));
            json_object_object_add(gpu, "model",     json_object_new_string(model));
            json_object_array_add(array, gpu);
            gpu_count++;
            extra_info[0] = '\0';

        } else if (strstr(line, "Parallel compute cores") ||
                   strstr(line, "Stream processors")) {
            strncpy(extra_info, line, sizeof(extra_info) - 1);
            _hw_trim(extra_info);

        } else if (strstr(line, "Max clock (MHz)")) {
            char clock[64] = "", final_info[256];
            sscanf(line, "%*[^:]: %63s", clock);
            if (extra_info[0])
                snprintf(final_info, sizeof(final_info), "%s, %s MHz", extra_info, clock);
            else
                snprintf(final_info, sizeof(final_info), "%s MHz", clock);

            json_object *gpu = json_object_array_get_idx(array, gpu_count - 1);
            if (gpu) {
                /* Benchmark this GPU directly — no temporary files */
                log_info("Benchmarking GPU device %d ...", gpu_count);
                double tp = _hw_benchmark_one_gpu(cfg->john_path, platform, gpu_count);
                json_object_object_add(gpu, "perf_info",  json_object_new_string(final_info));
                json_object_object_add(gpu, "throughput", json_object_new_double(tp));
                json_object_object_add(gpu, "status",     json_object_new_string("free"));
            }
        }
    }

    json_object_object_add(root, "gpus", array);
    pclose(fp);
    return root;
}

/* ════════════════════════════════════════════
 *  Node registration
 * ════════════════════════════════════════════ */

/*
 * Register this node with the API server.
 * Sends GPU registration first (if any GPUs), then CPU registration.
 */
static void hw_register_node(const Config *cfg, const char *node_ip) {
    char url[512], response[NET_BUFFER];
    snprintf(url, sizeof(url), "%s/register", cfg->api_url);

    /* GPU */
    log_info("Building GPU registration JSON (benchmark in progress) ...");
    json_object *gpu_json = hw_build_gpu_json(cfg, node_ip);
    if (gpu_json) {
        const char *gpu_str = json_object_to_json_string(gpu_json);
        log_info("Sending GPU registration to %s", url);
        if (http_post(url, gpu_str, response, sizeof(response)) == 0)
            log_info("GPU registration response: %s", response);
        else
            log_error("GPU registration failed");
        json_object_put(gpu_json);
    } else {
        log_warn("No GPU devices detected — skipping GPU registration");
    }

    /* CPU */
    log_info("Building CPU registration JSON (benchmark in progress) ...");
    json_object *cpu_json = hw_build_cpu_json(cfg, node_ip);
    if (cpu_json) {
        const char *cpu_str = json_object_to_json_string(cpu_json);
        log_info("Sending CPU registration to %s", url);
        if (http_post(url, cpu_str, response, sizeof(response)) == 0)
            log_info("CPU registration response: %s", response);
        else
            log_error("CPU registration failed");
        json_object_put(cpu_json);
    } else {
        log_error("Failed to build CPU registration JSON");
    }
}

#endif /* HARDWARE_H */
