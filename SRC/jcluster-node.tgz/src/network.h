/*
 * network.h — HTTP helpers for communication with the API server.
 *
 * Replaces the TCP send_json() approach.  Uses libcurl for all requests.
 *
 * Public API:
 *   http_post(url, json_body, response, resp_size)  — POST JSON, read response
 *   http_get (url, response, resp_size)             — GET, read response
 *
 * Compile with: -lcurl
 */
#ifndef NETWORK_H
#define NETWORK_H

#include <string.h>
#include <curl/curl.h>
#include "logger.h"

#define NET_BUFFER 524288   /* max response size (512 KiB) */

typedef struct { char *buf; size_t len; size_t cap; } _NetBuf;

static size_t _net_write(void *data, size_t sz, size_t nmemb, void *userp) {
    _NetBuf *b = (_NetBuf *)userp;
    size_t   n = sz * nmemb;
    if (b->len + n >= b->cap) return 0;
    memcpy(b->buf + b->len, data, n);
    b->len += n;
    b->buf[b->len] = '\0';
    return n;
}

/*
 * POST json_body to url; store response in response[0..resp_size-1].
 * Returns 0 on success, -1 on curl error.
 */
static int http_post(const char *url, const char *body,
                     char *response, size_t resp_size) {
    CURL *curl = curl_easy_init();
    if (!curl) return -1;

    _NetBuf rb = { response, 0, resp_size - 1 };
    if (response) response[0] = '\0';

    struct curl_slist *hdrs =
        curl_slist_append(NULL, "Content-Type: application/json");

    curl_easy_setopt(curl, CURLOPT_URL,           url);
    curl_easy_setopt(curl, CURLOPT_POST,          1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS,    body);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER,    hdrs);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, _net_write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &rb);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       30L);

    CURLcode rc = curl_easy_perform(curl);
    if (rc != CURLE_OK)
        log_error("http_post %s failed: %s", url, curl_easy_strerror(rc));

    curl_slist_free_all(hdrs);
    curl_easy_cleanup(curl);
    return rc == CURLE_OK ? 0 : -1;
}

/*
 * GET url; store response in response[0..resp_size-1].
 * Returns 0 on success, -1 on curl error.
 */
static int http_get(const char *url, char *response, size_t resp_size) {
    CURL *curl = curl_easy_init();
    if (!curl) return -1;

    _NetBuf rb = { response, 0, resp_size - 1 };
    if (response) response[0] = '\0';

    curl_easy_setopt(curl, CURLOPT_URL,           url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, _net_write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &rb);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       30L);

    CURLcode rc = curl_easy_perform(curl);
    if (rc != CURLE_OK)
        log_error("http_get %s failed: %s", url, curl_easy_strerror(rc));

    curl_easy_cleanup(curl);
    return rc == CURLE_OK ? 0 : -1;
}

#endif /* NETWORK_H */
