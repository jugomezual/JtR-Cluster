/*
 * jtr-cluster-node.c — Unified processing node for the JtR distributed cluster.
 *
 * Replaces the separate procesamiento.c, cpu_report.c, and gpu_report.c.
 *
 * Startup sequence:
 *   1. Load runtime config from config.txt (SERVER_IP, SERVER_PORT, JOHN_PATH).
 *   2. Detect the node's local IP address.
 *   3. Register with the server (GPU + CPU) — always, on every start.
 *   4. Detect available GPUs and CPUs.
 *   5. Launch one cracking thread per GPU and one per CPU core.
 *   6. Wait indefinitely (threads loop forever requesting jobs).
 *
 * Compile:
 *   gcc -o jtr-cluster jtr-cluster-node.c \
 *       -ljson-c -lpthread -Wall -O2
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>

#include "logger.h"
#include "config.h"
#include "network.h"
#include "hardware.h"
#include "worker.h"

#define MAX_GPUS 32
#define MAX_CPUS 128

/* ── Kill competing instances and clean stale temp files ── */
static void startup_cleanup(void) {
    pid_t self = getpid();
    char cmd[512];

    /* 1. Kill any other jtr-cluster processes (not self) */
    snprintf(cmd, sizeof(cmd),
        "for pid in $(pgrep -x jtr-cluster 2>/dev/null); do "
        "  [ \"$pid\" != \"%d\" ] && kill -9 \"$pid\" 2>/dev/null; "
        "done",
        (int)self);
    system(cmd);

    /* 2. Remove stale temp files */
    system("rm -f potfile_gpu*.txt potfile_cpu*.txt "
           "session_gpu*.rec session_cpu*.rec "
           "hashes/*.txt 2>/dev/null");

    /* 3. Kill any lingering john processes */
    system("pkill -9 -x john 2>/dev/null; true");

    /* 4. Remove stale john .rec files */
    system("rm -f *.rec 2>/dev/null; true");

    /* 5. Remove devices.txt if it still exists from a previous install */
    system("rm -f devices.txt 2>/dev/null; true");

    sleep(1); /* allow killed processes to fully exit */
}

/* ── Detect this machine's outbound IP address ── */
static void get_local_ip(char *buf, size_t size) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        strncpy(buf, "127.0.0.1", size - 1);
        return;
    }
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(53);
    inet_pton(AF_INET, "8.8.8.8", &addr.sin_addr);
    connect(sock, (const struct sockaddr *)&addr, sizeof(addr));
    struct sockaddr_in local = {0};
    socklen_t len = sizeof(local);
    getsockname(sock, (struct sockaddr *)&local, &len);
    inet_ntop(AF_INET, &local.sin_addr, buf, size);
    close(sock);
}

/* ── Main ── */
int main(void) {
    log_open(LOG_PATH);
    log_info("=== processing_node starting ===");

    /* 0. Cleanup: kill stale instances + john processes, remove temp files */
    startup_cleanup();
    log_info("Startup cleanup done.");

    /* 1. Load config */
    Config cfg;
    if (config_load(&cfg, NULL))
        log_info("Config loaded from %s", CONFIG_FILE);
    else
        log_info("Config file not found — using defaults (api=%s)", cfg.api_url);

    log_info("API URL:   %s", cfg.api_url);
    log_info("John path: %s", cfg.john_path);

    /* 2. Detect local IP */
    char node_ip[64] = "127.0.0.1";
    get_local_ip(node_ip, sizeof(node_ip));
    log_info("Node IP:   %s", node_ip);

    /* 3. Register with server (always — no fingerprint file) */
    log_info("Registering with server ...");
    hw_register_node(&cfg, node_ip);
    log_info("Registration complete.");

    /* 4. Detect GPUs */
    int  gpu_ids[MAX_GPUS]  = {0};
    char gpu_platform[128]  = "";
    int  num_gpus = hw_detect_gpus(&cfg, gpu_ids, MAX_GPUS,
                                    gpu_platform, sizeof(gpu_platform));

    /* 5. Detect online CPUs (reads /sys/devices/system/cpu/online) */
    int cpu_ids[1024] = {0};
    int num_cpus = hw_get_online_cpus(cpu_ids, 1024);

    log_info("Detected %d GPU(s) [platform: %s]",
             num_gpus, gpu_platform[0] ? gpu_platform : "auto");
    log_info("Detected %d online CPU core(s)", num_cpus);

    if (num_gpus == 0 && num_cpus == 0) {
        log_error("No GPU or CPU workers available — exiting.");
        log_close();
        return 1;
    }

    /* 6. Launch GPU threads */
    pthread_t *gpu_threads = NULL;
    if (num_gpus > 0) {
        gpu_threads = malloc(num_gpus * sizeof(pthread_t));
        for (int i = 0; i < num_gpus; i++) {
            WorkerArgsGpu *w = malloc(sizeof(WorkerArgsGpu));
            w->id_gpu = gpu_ids[i];
            strncpy(w->node_ip,  node_ip,      sizeof(w->node_ip)   - 1);
            strncpy(w->platform, gpu_platform, sizeof(w->platform)  - 1);
            w->cfg = cfg;
            pthread_create(&gpu_threads[i], NULL, worker_loop_gpu, w);
            usleep(500000); /* stagger thread starts */
        }
        log_info("Launched %d GPU worker thread(s)", num_gpus);
    }

    /* 7. Launch CPU threads — one per online CPU ID */
    pthread_t *cpu_threads = NULL;
    if (num_cpus > 0) {
        cpu_threads = malloc(num_cpus * sizeof(pthread_t));
        for (int i = 0; i < num_cpus; i++) {
            WorkerArgsCpu *w = malloc(sizeof(WorkerArgsCpu));
            w->id_cpu = cpu_ids[i];
            strncpy(w->node_ip, node_ip, sizeof(w->node_ip) - 1);
            w->cfg = cfg;
            pthread_create(&cpu_threads[i], NULL, worker_loop_cpu, w);
            usleep(500000);
        }
        log_info("Launched %d CPU worker thread(s)", num_cpus);
    }

    /* 8. Wait for threads (they loop forever) */
    for (int i = 0; i < num_gpus; i++) pthread_join(gpu_threads[i], NULL);
    for (int i = 0; i < num_cpus; i++) pthread_join(cpu_threads[i], NULL);

    free(gpu_threads);
    free(cpu_threads);
    log_close();
    return 0;
}
